'use client';
import { useState } from 'react';
import { api, Message } from '@/components/ui';

export default function LoginPage() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  async function submit(e) {
    e.preventDefault();
    try {
      await api('/api/auth/login', 'POST', { username, password });
      window.location.href = '/';
    } catch (err) {
      setError(err.message);
    }
  }

  return (
    <div className="login">
      <form onSubmit={submit}>
        <h2>Hospital Management</h2>
        <p className="muted" style={{ margin: 0 }}>Sign in to continue</p>
        <label>Username<input required value={username} onChange={(e) => setUsername(e.target.value)} /></label>
        <label>Password<input required type="password" value={password} onChange={(e) => setPassword(e.target.value)} /></label>
        <Message error={error} />
        <button className="btn">Log in</button>
      </form>
    </div>
  );
}
