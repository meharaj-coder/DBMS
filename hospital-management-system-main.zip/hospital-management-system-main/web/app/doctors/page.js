'use client';
import { Message, Table, money, useData } from '@/components/ui';

export default function DoctorsPage() {
  const [doctors, , error] = useData('/api/doctors');
  return (
    <>
      <h2>Doctors</h2>
      <div className="card">
        <Message error={error} />
        <Table
          rowKey="doctor_id"
          rows={doctors}
          columns={[
            { label: 'Name', render: (d) => `Dr. ${d.first_name} ${d.last_name}` },
            { key: 'department', label: 'Department' },
            { key: 'specialization', label: 'Specialization' },
            { label: 'Experience', render: (d) => `${d.experience_years} years` },
            { label: 'Fee', render: (d) => money(d.consultation_fee) },
            { key: 'email', label: 'Email' },
          ]}
        />
      </div>
    </>
  );
}
