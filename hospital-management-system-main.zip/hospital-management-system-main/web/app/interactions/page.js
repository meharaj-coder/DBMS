'use client';
import { useState } from 'react';
import { api, Form, Message, Status, Table, useData } from '@/components/ui';

const SEVERITY_OPTIONS = ['MINOR', 'MODERATE', 'MAJOR'].map((s) => ({ value: s, label: s }));

export default function InteractionsPage() {
  const [filter, setFilter] = useState('');
  const [rows, reload, error] = useData(`/api/interactions${filter ? `?medicine=${filter}` : ''}`);
  const [medicines] = useData('/api/medicines');
  const [me] = useData('/api/auth/me');
  const [editing, setEditing] = useState(null);
  const [actionError, setActionError] = useState('');
  const canEdit = me?.role === 'ADMIN' || me?.role === 'PHARMACIST';
  const medicineOptions = (medicines || []).map((m) => ({ value: m.medicine_id, label: m.name }));

  async function remove(r) {
    if (!confirm(`Delete the interaction between ${r.a_name} and ${r.b_name}?`)) return;
    setActionError('');
    try {
      await api(`/api/interactions/${r.a_id}/${r.b_id}`, 'DELETE');
      reload();
    } catch (err) {
      setActionError(err.message);
    }
  }

  const columns = [
    { key: 'a_name', label: 'Medicine' },
    { key: 'b_name', label: 'Interacts with' },
    { label: 'Severity', render: (r) => <Status value={r.severity} /> },
    { key: 'effect', label: 'Effect' },
  ];
  if (canEdit) {
    columns.push({
      label: 'Actions',
      render: (r) => (
        <>
          <button className="btn btn-small btn-light" onClick={() => setEditing(r)}>Edit</button>
          <button className="btn btn-small btn-danger" onClick={() => remove(r)}>Delete</button>
        </>
      ),
    });
  }

  return (
    <>
      <h2>Drug Interactions</h2>
      <p className="muted">Stored in Neo4j as Medicine nodes joined by INTERACTS_WITH relationships. Sample data, not medical advice.</p>
      {canEdit && (
        <div className="two-col">
          <div className="card">
            <h3>Add an interaction</h3>
            <Form
              submitLabel="Add"
              fields={[
                { name: 'a_id', label: 'Medicine 1', required: true, options: medicineOptions },
                { name: 'b_id', label: 'Medicine 2', required: true, options: medicineOptions },
                { name: 'severity', label: 'Severity', required: true, options: SEVERITY_OPTIONS },
                { name: 'effect', label: 'Effect', required: true },
              ]}
              onSubmit={async (v) => { await api('/api/interactions', 'POST', v); reload(); }}
            />
          </div>
          {editing && (
            <div className="card">
              <h3>{editing.a_name} and {editing.b_name}</h3>
              <Form
                submitLabel="Update"
                initial={editing}
                fields={[
                  { name: 'severity', label: 'Severity', required: true, options: SEVERITY_OPTIONS },
                  { name: 'effect', label: 'Effect', required: true },
                ]}
                onSubmit={async (v) => { await api(`/api/interactions/${editing.a_id}/${editing.b_id}`, 'PUT', v); setEditing(null); reload(); }}
              />
            </div>
          )}
        </div>
      )}
      <div className="card">
        <div className="searchbar">
          <select value={filter} onChange={(e) => setFilter(e.target.value)}>
            <option value="">All medicines</option>
            {medicineOptions.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
          </select>
        </div>
        <Message error={error || actionError} />
        <Table columns={columns} rows={rows} />
      </div>
    </>
  );
}
