'use client';
import { useState } from 'react';
import { api, Form, Message, Table, money, useData } from '@/components/ui';

export default function PharmacyPage() {
  const [stock, reloadStock, stockError] = useData('/api/pharmacy/stock');
  const [pending, reloadPending] = useData('/api/pharmacy/pending');
  const [suppliers] = useData('/api/suppliers');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  async function dispense(id) {
    setError('');
    setSuccess('');
    try {
      await api(`/api/pharmacy/dispense/${id}`, 'POST', {});
      setSuccess(`Prescription #${id} dispensed and added to the bill.`);
      reloadPending();
      reloadStock();
    } catch (err) {
      setError(err.message);
    }
  }

  const batchFields = [
    { name: 'medicine_id', label: 'Medicine', required: true, options: (stock || []).map((m) => ({ value: m.medicine_id, label: m.name })) },
    { name: 'batch_no', label: 'Batch number', required: true },
    { name: 'quantity', label: 'Quantity', type: 'number', min: 1, required: true },
    { name: 'expiry_date', label: 'Expiry date', type: 'date', required: true },
  ];
  const medicineFields = [
    { name: 'name', label: 'Name', required: true },
    { name: 'supplier_id', label: 'Supplier', required: true, options: (suppliers || []).map((s) => ({ value: s.supplier_id, label: s.name })) },
    { name: 'unit_price', label: 'Unit price', type: 'number', min: 0, step: '0.01', required: true },
    { name: 'reorder_level', label: 'Reorder level', type: 'number', min: 0, required: true },
  ];

  return (
    <>
      <h2>Pharmacy</h2>
      <div className="card">
        <h3>Prescriptions to dispense</h3>
        <Message error={error} success={success} />
        <Table
          rowKey="prescription_id"
          rows={pending}
          empty="Nothing waiting."
          columns={[
            { key: 'prescription_id', label: '#' },
            { key: 'patient_name', label: 'Patient' },
            { key: 'doctor_name', label: 'Doctor' },
            { key: 'medicines', label: 'Medicines' },
            { label: '', render: (r) => <button className="btn btn-small" onClick={() => dispense(r.prescription_id)}>Dispense</button> },
          ]}
        />
      </div>
      <div className="card">
        <h3>Stock</h3>
        <Message error={stockError} />
        <Table
          rowKey="medicine_id"
          rows={stock}
          columns={[
            { key: 'name', label: 'Medicine' },
            { key: 'supplier', label: 'Supplier' },
            { label: 'Price', render: (m) => money(m.unit_price) },
            { key: 'on_hand', label: 'On hand' },
            { key: 'reorder_level', label: 'Reorder level' },
            { key: 'next_expiry', label: 'Next expiry' },
            { label: 'Status', render: (m) => (m.on_hand < m.reorder_level ? <span className="badge badge-UNPAID">REORDER</span> : <span className="badge badge-PAID">OK</span>) },
          ]}
        />
      </div>
      <div className="two-col">
        <div className="card">
          <h3>Receive a batch</h3>
          <Form fields={batchFields} submitLabel="Add batch" onSubmit={async (v) => { await api('/api/pharmacy/batches', 'POST', v); reloadStock(); }} />
        </div>
        <div className="card">
          <h3>Add a medicine</h3>
          <Form fields={medicineFields} submitLabel="Add medicine" onSubmit={async (v) => { await api('/api/medicines', 'POST', v); reloadStock(); }} />
        </div>
      </div>
    </>
  );
}
