'use client';
import { useEffect, useState } from 'react';
import { api, Message, Status, Table, useData } from '@/components/ui';

const EMPTY_LINE = { medicine_id: '', dosage: '1 tablet', frequency: 'Twice daily', duration_days: 5, quantity: 10 };

function NewPrescription({ onSaved }) {
  const [appointments] = useData('/api/appointments');
  const [medicines] = useData('/api/medicines');
  const [appointmentId, setAppointmentId] = useState('');
  const [diagnosis, setDiagnosis] = useState('');
  const [notes, setNotes] = useState('');
  const [lines, setLines] = useState([{ ...EMPTY_LINE }]);
  const [warnings, setWarnings] = useState([]);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // Ask Neo4j for interactions between the chosen medicines whenever they change.
  const chosenIds = lines.map((l) => l.medicine_id).filter(Boolean).join(',');
  useEffect(() => {
    if (!chosenIds.includes(',')) { setWarnings([]); return; }
    api('/api/interactions/check', 'POST', { ids: chosenIds.split(',') }).then(setWarnings).catch(() => setWarnings([]));
  }, [chosenIds]);

  const setLine = (i, name, value) => setLines(lines.map((l, j) => (j === i ? { ...l, [name]: value } : l)));

  async function save(e) {
    e.preventDefault();
    setError('');
    setSuccess('');
    try {
      await api('/api/prescriptions', 'POST', { appointment_id: appointmentId, diagnosis, notes, medicines: lines });
      setAppointmentId(''); setDiagnosis(''); setNotes(''); setLines([{ ...EMPTY_LINE }]);
      setSuccess('Prescription saved.');
      onSaved();
    } catch (err) {
      setError(err.message);
    }
  }

  return (
    <div className="card">
      <h3>Write a prescription</h3>
      <form onSubmit={save}>
        <div className="form-grid">
          <label>Appointment
            <select required value={appointmentId} onChange={(e) => setAppointmentId(e.target.value)}>
              <option value="">Select...</option>
              {appointments?.filter((a) => a.status !== 'CANCELLED' && a.status !== 'NO_SHOW').map((a) => (
                <option key={a.appointment_id} value={a.appointment_id}>{a.appointment_date} {a.start_time} - {a.patient_name}</option>
              ))}
            </select>
          </label>
          <label>Diagnosis<input required value={diagnosis} onChange={(e) => setDiagnosis(e.target.value)} /></label>
          <label>Notes<input value={notes} onChange={(e) => setNotes(e.target.value)} /></label>
        </div>

        {lines.map((line, i) => (
          <div className="form-grid" key={i}>
            <label>Medicine
              <select required value={line.medicine_id} onChange={(e) => setLine(i, 'medicine_id', e.target.value)}>
                <option value="">Select...</option>
                {medicines?.map((m) => <option key={m.medicine_id} value={m.medicine_id}>{m.name}</option>)}
              </select>
            </label>
            <label>Dosage<input required value={line.dosage} onChange={(e) => setLine(i, 'dosage', e.target.value)} /></label>
            <label>Frequency<input required value={line.frequency} onChange={(e) => setLine(i, 'frequency', e.target.value)} /></label>
            <label>Days<input required type="number" min="1" value={line.duration_days} onChange={(e) => setLine(i, 'duration_days', e.target.value)} /></label>
            <label>Quantity<input required type="number" min="1" value={line.quantity} onChange={(e) => setLine(i, 'quantity', e.target.value)} /></label>
          </div>
        ))}

        {warnings.map((w) => (
          <p className="msg msg-warn" key={`${w.a_id}-${w.b_id}`}>
            <Status value={w.severity} /> <b>{w.a_name}</b> and <b>{w.b_name}</b>: {w.effect}
          </p>
        ))}
        <Message error={error} success={success} />
        <button type="button" className="btn btn-light" style={{ marginRight: 8 }} onClick={() => setLines([...lines, { ...EMPTY_LINE }])}>Add medicine</button>
        <button className="btn">Save prescription</button>
      </form>
    </div>
  );
}

export default function PrescriptionsPage() {
  const [search, setSearch] = useState('');
  const [query, setQuery] = useState('');
  const [rows, reload, error] = useData(`/api/prescriptions${query ? `?q=${encodeURIComponent(query)}` : ''}`);
  const [me] = useData('/api/auth/me');
  const isDoctor = me?.role === 'DOCTOR';

  return (
    <>
      <h2>Prescriptions</h2>
      {isDoctor && <NewPrescription onSaved={reload} />}
      <div className="card">
        <form className="searchbar" onSubmit={(e) => { e.preventDefault(); setQuery(search); }}>
          <input placeholder="Search diagnoses, e.g. fever" value={search} onChange={(e) => setSearch(e.target.value)} />
          <button className="btn">Search</button>
        </form>
        <Message error={error} />
        <Table
          rowKey="prescription_id"
          rows={rows}
          empty="No prescriptions found."
          columns={[
            { key: 'prescribed_on', label: 'Date' },
            { key: 'patient_name', label: 'Patient' },
            { key: 'doctor_name', label: 'Doctor' },
            { key: 'diagnosis', label: 'Diagnosis' },
            { key: 'medicines', label: 'Medicines' },
          ]}
        />
      </div>
    </>
  );
}
