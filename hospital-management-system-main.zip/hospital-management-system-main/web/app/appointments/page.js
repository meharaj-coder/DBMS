'use client';
import { useState } from 'react';
import { api, Form, Message, Status, Table, useData } from '@/components/ui';

function BookingForm({ onBooked }) {
  const [patients] = useData('/api/patients');
  const [doctors] = useData('/api/doctors');
  const [picked, setPicked] = useState({});
  const slotsUrl = picked.doctor_id && picked.date ? `/api/doctors/${picked.doctor_id}/slots?date=${picked.date}` : null;
  const [slots] = useData(slotsUrl);

  const fields = [
    { name: 'patient_id', label: 'Patient', required: true, options: (patients || []).map((p) => ({ value: p.patient_id, label: `${p.first_name} ${p.last_name}` })) },
    { name: 'doctor_id', label: 'Doctor', required: true, options: (doctors || []).map((d) => ({ value: d.doctor_id, label: `Dr. ${d.first_name} ${d.last_name} (${d.department})` })) },
    { name: 'date', label: 'Date', type: 'date', required: true, min: new Date().toLocaleDateString('en-CA') },
    { name: 'time', label: 'Free slot', required: true, options: (slots || []).map((s) => ({ value: s, label: s })) },
    { name: 'reason', label: 'Reason' },
  ];

  async function book(values) {
    await api('/api/appointments', 'POST', values);
    onBooked();
  }

  return (
    <div className="card">
      <h3>Book an appointment</h3>
      <Form fields={fields} onSubmit={book} onChange={setPicked} submitLabel="Book" />
    </div>
  );
}

export default function AppointmentsPage() {
  const [appointments, reload, error] = useData('/api/appointments');
  const [me] = useData('/api/auth/me');
  const [actionError, setActionError] = useState('');
  const isFrontDesk = me?.role === 'ADMIN' || me?.role === 'RECEPTIONIST';
  const isDoctor = me?.role === 'DOCTOR';

  async function act(id, action) {
    setActionError('');
    try {
      await api(`/api/appointments/${id}`, 'PATCH', { action });
      reload();
    } catch (err) {
      setActionError(err.message);
    }
  }

  return (
    <>
      <h2>Appointments</h2>
      {isFrontDesk && <BookingForm onBooked={reload} />}
      <div className="card">
        <Message error={error || actionError} />
        <Table
          rowKey="appointment_id"
          rows={appointments}
          columns={[
            { key: 'appointment_date', label: 'Date' },
            { key: 'start_time', label: 'Time' },
            { key: 'patient_name', label: 'Patient' },
            { key: 'doctor_name', label: 'Doctor' },
            { key: 'reason', label: 'Reason' },
            { label: 'Status', render: (a) => <Status value={a.status} /> },
            {
              label: 'Actions',
              render: (a) => a.status === 'SCHEDULED' && (
                <>
                  {isDoctor && <button className="btn btn-small" onClick={() => act(a.appointment_id, 'complete')}>Complete</button>}
                  {isFrontDesk && <button className="btn btn-small btn-danger" onClick={() => act(a.appointment_id, 'cancel')}>Cancel</button>}
                </>
              ),
            },
          ]}
        />
      </div>
    </>
  );
}
