import { route } from '@/lib/route';

export const GET = route(['ADMIN', 'DOCTOR', 'RECEPTIONIST'], async ({ db }) => {
  const { rows } = await db.query('SELECT * FROM v_doctor ORDER BY department, last_name');
  return rows;
});
