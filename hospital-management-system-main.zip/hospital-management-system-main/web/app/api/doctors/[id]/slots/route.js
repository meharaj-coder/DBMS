import { route } from '@/lib/route';

export const GET = route(['ADMIN', 'RECEPTIONIST'], async ({ db, params, query }) => {
  const { rows } = await db.query(
    "SELECT to_char(slot_time, 'HH24:MI') AS slot FROM fn_available_slots($1, $2)",
    [params.id, query.get('date')],
  );
  return rows.map((r) => r.slot);
});
