import { route } from '@/lib/route';
import { cypher, toInt } from '@/lib/neo4j';

export const GET = route(['ADMIN', 'DOCTOR', 'PHARMACIST'], async ({ db }) => {
  const { rows } = await db.query('SELECT medicine_id, name, unit_price FROM medicine ORDER BY name');
  return rows;
});

// A new medicine is saved in PostgreSQL and added as a node to the graph.
export const POST = route(['ADMIN', 'PHARMACIST'], async ({ db, body }) => {
  const { rows } = await db.query(
    `INSERT INTO medicine (supplier_id, name, unit_price, reorder_level)
     VALUES ($1, $2, $3, $4) RETURNING medicine_id`,
    [body.supplier_id, body.name, body.unit_price, body.reorder_level],
  );
  await cypher('MERGE (m:Medicine {medicine_id: $id}) SET m.name = $name', { id: toInt(rows[0].medicine_id), name: body.name });
  return rows[0];
});
