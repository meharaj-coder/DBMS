import { route } from '@/lib/route';

// Doctors only see their own appointments.
export const GET = route(['ADMIN', 'DOCTOR', 'RECEPTIONIST'], async ({ db, user }) => {
  const { rows } = await db.query(
    `SELECT appointment_id, appointment_date, to_char(start_time, 'HH24:MI') AS start_time,
            status, reason, patient_name, doctor_name
     FROM   v_appointment
     WHERE  $1::INT IS NULL OR doctor_id = $1
     ORDER  BY appointment_date DESC, start_time`,
    [user.role === 'DOCTOR' ? user.doctorId : null],
  );
  return rows;
});

export const POST = route(['ADMIN', 'RECEPTIONIST'], async ({ db, body }) => {
  await db.query('CALL sp_book_appointment($1, $2, $3, $4, $5)',
    [body.patient_id, body.doctor_id, body.date, body.time, body.reason]);
});
