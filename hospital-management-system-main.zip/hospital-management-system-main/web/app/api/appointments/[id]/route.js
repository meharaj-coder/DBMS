import { ApiError, route } from '@/lib/route';

// action 'complete' creates the bill; action 'cancel' frees the slot.
export const PATCH = route(['ADMIN', 'DOCTOR', 'RECEPTIONIST'], async ({ db, user, params, body }) => {
  if (body.action === 'complete') {
    if (user.role === 'RECEPTIONIST') throw new ApiError(403, 'Only a doctor can complete an appointment.');
    if (user.role === 'DOCTOR') {
      const { rows } = await db.query(
        'SELECT 1 FROM appointment WHERE appointment_id = $1 AND doctor_id = $2', [params.id, user.doctorId]);
      if (rows.length === 0) throw new ApiError(403, 'This is not your appointment.');
    }
    await db.query('CALL sp_complete_appointment($1)', [params.id]);
  } else if (body.action === 'cancel') {
    if (user.role === 'DOCTOR') throw new ApiError(403, 'Ask the front desk to cancel an appointment.');
    const result = await db.query(
      "UPDATE appointment SET status = 'CANCELLED' WHERE appointment_id = $1 AND status = 'SCHEDULED'", [params.id]);
    if (result.rowCount === 0) throw new ApiError(400, 'Only a scheduled appointment can be cancelled.');
  } else {
    throw new ApiError(400, 'Unknown action.');
  }
});
