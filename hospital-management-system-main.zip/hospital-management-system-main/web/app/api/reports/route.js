import { route } from '@/lib/route';

export const GET = route(['ADMIN'], async ({ db }) => {
  const revenue = await db.query('SELECT * FROM v_monthly_revenue ORDER BY month');
  const ranking = await db.query('SELECT * FROM v_doctor_ranking ORDER BY department, rank_in_department');
  const occupancy = await db.query('SELECT * FROM v_bed_occupancy ORDER BY ward');
  // Nested query: patients whose total billing is above the average patient's total.
  const topPatients = await db.query(`
    SELECT p.first_name || ' ' || p.last_name AS patient_name, SUM(fn_bill_total(b.bill_id)) AS total_billed
    FROM   patient p JOIN bill b ON b.patient_id = p.patient_id
    GROUP  BY p.patient_id, p.first_name, p.last_name
    HAVING SUM(fn_bill_total(b.bill_id)) > (
        SELECT AVG(patient_total)
        FROM  (SELECT SUM(fn_bill_total(bill_id)) AS patient_total FROM bill GROUP BY patient_id) AS totals)
    ORDER  BY total_billed DESC`);
  return { revenue: revenue.rows, ranking: ranking.rows, occupancy: occupancy.rows, topPatients: topPatients.rows };
});
