import { route } from '@/lib/route';

export const GET = route(['ADMIN', 'PHARMACIST'], async ({ db }) => {
  const { rows } = await db.query('SELECT * FROM v_pending_prescription ORDER BY prescribed_on');
  return rows;
});
