import { route } from '@/lib/route';

export const POST = route(['ADMIN', 'PHARMACIST'], async ({ db, params }) => {
  await db.query('CALL sp_dispense_prescription($1)', [params.id]);
});
