import { route } from '@/lib/route';

export const GET = route(['ADMIN', 'PHARMACIST'], async ({ db }) => {
  const { rows } = await db.query('SELECT * FROM v_stock ORDER BY name');
  return rows;
});
