import { route } from '@/lib/route';

export const POST = route(['ADMIN', 'PHARMACIST'], async ({ db, body }) => {
  await db.query(
    'INSERT INTO stock_batch (medicine_id, batch_no, quantity, expiry_date) VALUES ($1, $2, $3, $4)',
    [body.medicine_id, body.batch_no, body.quantity, body.expiry_date],
  );
});
