import { route } from '@/lib/route';

export const GET = route(['ADMIN', 'DOCTOR', 'RECEPTIONIST'], async ({ db, query }) => {
  const { rows } = await db.query(
    `SELECT * FROM v_patient
     WHERE  first_name || ' ' || last_name ILIKE $1
     ORDER  BY patient_id`,
    [`%${query.get('q') || ''}%`],
  );
  return rows;
});

// The patient and their phone number are saved in one transaction.
export const POST = route(['ADMIN', 'RECEPTIONIST'], async ({ db, body }) => {
  const { rows } = await db.query(
    `INSERT INTO patient (first_name, last_name, date_of_birth, gender, blood_group, street, city, state, zip)
     VALUES ($1, $2, $3, $4, NULLIF($5, ''), $6, $7, $8, NULLIF($9, ''))
     RETURNING patient_id`,
    [body.first_name, body.last_name, body.date_of_birth, body.gender, body.blood_group || '',
     body.street, body.city, body.state, body.zip || ''],
  );
  if (body.phone) {
    await db.query('INSERT INTO patient_phone (patient_id, phone_no) VALUES ($1, $2)', [rows[0].patient_id, body.phone]);
  }
  return rows[0];
});
