import { route } from '@/lib/route';

export const PUT = route(['ADMIN', 'RECEPTIONIST'], async ({ db, params, body }) => {
  await db.query(
    `UPDATE patient
     SET    first_name = $2, last_name = $3, date_of_birth = $4, gender = $5, blood_group = NULLIF($6, ''),
            street = $7, city = $8, state = $9, zip = NULLIF($10, '')
     WHERE  patient_id = $1`,
    [params.id, body.first_name, body.last_name, body.date_of_birth, body.gender, body.blood_group || '',
     body.street, body.city, body.state, body.zip || ''],
  );
  if (body.phone) {
    await db.query(
      'INSERT INTO patient_phone (patient_id, phone_no) VALUES ($1, $2) ON CONFLICT DO NOTHING',
      [params.id, body.phone],
    );
  }
});

// Fails with a clear message if the patient has appointments, thanks to the foreign keys.
export const DELETE = route(['ADMIN', 'RECEPTIONIST'], async ({ db, params }) => {
  await db.query('DELETE FROM patient WHERE patient_id = $1', [params.id]);
});
