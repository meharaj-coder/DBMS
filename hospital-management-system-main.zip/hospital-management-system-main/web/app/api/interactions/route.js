import { ApiError, route } from '@/lib/route';
import { cypher, toInt } from '@/lib/neo4j';

const SEVERITIES = ['MINOR', 'MODERATE', 'MAJOR'];

// Read: every interaction, optionally only those involving one medicine.
export const GET = route(['ADMIN', 'DOCTOR', 'PHARMACIST'], async ({ query }) => {
  const medicine = query.get('medicine');
  return cypher(
    `MATCH (a:Medicine)-[r:INTERACTS_WITH]->(b:Medicine)
     WHERE $medicine IS NULL OR a.medicine_id = $medicine OR b.medicine_id = $medicine
     RETURN a.medicine_id AS a_id, a.name AS a_name, b.medicine_id AS b_id, b.name AS b_name,
            r.severity AS severity, r.effect AS effect
     ORDER BY a_name, b_name`,
    { medicine: medicine ? toInt(medicine) : null },
  );
});

// Create. Each pair is stored once, with the lower id as the start of the relationship.
export const POST = route(['ADMIN', 'PHARMACIST'], async ({ body }) => {
  const a = Number(body.a_id);
  const b = Number(body.b_id);
  if (a === b) throw new ApiError(400, 'Choose two different medicines.');
  if (!SEVERITIES.includes(body.severity)) throw new ApiError(400, 'Choose a severity.');
  const rows = await cypher(
    `MATCH (a:Medicine {medicine_id: $low}), (b:Medicine {medicine_id: $high})
     MERGE (a)-[r:INTERACTS_WITH]->(b)
     SET r.severity = $severity, r.effect = $effect
     RETURN a.name AS a_name`,
    { low: toInt(Math.min(a, b)), high: toInt(Math.max(a, b)), severity: body.severity, effect: body.effect },
  );
  if (rows.length === 0) throw new ApiError(404, 'Medicine not found in the graph.');
});
