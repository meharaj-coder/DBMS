import { ApiError, route } from '@/lib/route';
import { cypher, toInt } from '@/lib/neo4j';

// Update
export const PUT = route(['ADMIN', 'PHARMACIST'], async ({ params, body }) => {
  if (!['MINOR', 'MODERATE', 'MAJOR'].includes(body.severity)) throw new ApiError(400, 'Choose a severity.');
  await cypher(
    `MATCH (:Medicine {medicine_id: $a})-[r:INTERACTS_WITH]->(:Medicine {medicine_id: $b})
     SET r.severity = $severity, r.effect = $effect`,
    { a: toInt(params.a), b: toInt(params.b), severity: body.severity, effect: body.effect },
  );
});

// Delete
export const DELETE = route(['ADMIN', 'PHARMACIST'], async ({ params }) => {
  await cypher(
    'MATCH (:Medicine {medicine_id: $a})-[r:INTERACTS_WITH]->(:Medicine {medicine_id: $b}) DELETE r',
    { a: toInt(params.a), b: toInt(params.b) },
  );
});
