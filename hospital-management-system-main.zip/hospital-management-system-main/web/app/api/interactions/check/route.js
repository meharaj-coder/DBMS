import { route } from '@/lib/route';
import { cypher, toInt } from '@/lib/neo4j';

// Finds interactions between the medicines on a prescription.
export const POST = route(['ADMIN', 'DOCTOR', 'PHARMACIST'], async ({ body }) => {
  return cypher(
    `MATCH (a:Medicine)-[r:INTERACTS_WITH]->(b:Medicine)
     WHERE a.medicine_id IN $ids AND b.medicine_id IN $ids
     RETURN a.medicine_id AS a_id, a.name AS a_name, b.medicine_id AS b_id, b.name AS b_name,
            r.severity AS severity, r.effect AS effect`,
    { ids: body.ids.map(toInt) },
  );
});
