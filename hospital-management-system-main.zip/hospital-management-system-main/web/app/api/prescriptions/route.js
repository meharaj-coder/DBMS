import { ApiError, route } from '@/lib/route';

// With ?q= this uses PostgreSQL full-text search on the diagnosis, best match first.
export const GET = route(['ADMIN', 'DOCTOR'], async ({ db, query }) => {
  const q = query.get('q');
  const { rows } = await db.query(
    `SELECT r.prescription_id, r.prescribed_on, r.diagnosis, r.notes, a.patient_name, a.doctor_name,
            (SELECT STRING_AGG(m.name || ' (' || pm.dosage || ', ' || pm.frequency || ')', '; ')
             FROM   prescription_medicine pm JOIN medicine m ON m.medicine_id = pm.medicine_id
             WHERE  pm.prescription_id = r.prescription_id) AS medicines
     FROM   prescription r
     JOIN   v_appointment a ON a.appointment_id = r.appointment_id
     WHERE  $1::TEXT IS NULL OR to_tsvector('english', r.diagnosis) @@ plainto_tsquery('english', $1)
     ORDER  BY CASE WHEN $1 IS NULL THEN 0
                    ELSE ts_rank(to_tsvector('english', r.diagnosis), plainto_tsquery('english', $1)) END DESC,
               r.prescribed_on DESC`,
    [q || null],
  );
  return rows;
});

// The prescription and its medicines are saved in one transaction.
export const POST = route(['DOCTOR'], async ({ db, user, body }) => {
  const own = await db.query(
    "SELECT 1 FROM appointment WHERE appointment_id = $1 AND doctor_id = $2 AND status <> 'CANCELLED'",
    [body.appointment_id, user.doctorId],
  );
  if (own.rows.length === 0) throw new ApiError(403, 'This is not one of your active appointments.');
  if (!body.medicines?.length) throw new ApiError(400, 'Add at least one medicine.');

  const { rows } = await db.query(
    'INSERT INTO prescription (appointment_id, diagnosis, notes) VALUES ($1, $2, $3) RETURNING prescription_id',
    [body.appointment_id, body.diagnosis, body.notes],
  );
  for (const m of body.medicines) {
    await db.query(
      `INSERT INTO prescription_medicine (prescription_id, medicine_id, dosage, frequency, duration_days, quantity)
       VALUES ($1, $2, $3, $4, $5, $6)`,
      [rows[0].prescription_id, m.medicine_id, m.dosage, m.frequency, m.duration_days, m.quantity],
    );
  }
  return rows[0];
});
