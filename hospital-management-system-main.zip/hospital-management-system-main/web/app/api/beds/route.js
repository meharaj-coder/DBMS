import { route } from '@/lib/route';

export const GET = route(['ADMIN', 'DOCTOR', 'RECEPTIONIST'], async ({ db }) => {
  const { rows } = await db.query('SELECT * FROM bed ORDER BY ward, bed_no');
  return rows;
});
