import { route } from '@/lib/route';

export const POST = route(['ADMIN', 'RECEPTIONIST'], async ({ db, params }) => {
  await db.query('CALL sp_discharge_patient($1)', [params.id]);
});
