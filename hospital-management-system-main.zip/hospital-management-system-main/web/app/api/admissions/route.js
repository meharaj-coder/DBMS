import { ApiError, route } from '@/lib/route';

export const GET = route(['ADMIN', 'DOCTOR', 'RECEPTIONIST'], async ({ db, user }) => {
  const { rows } = await db.query(
    `SELECT * FROM v_admission
     WHERE  $1::INT IS NULL OR doctor_id = $1
     ORDER  BY discharged_on DESC NULLS FIRST, admitted_on DESC`,
    [user.role === 'DOCTOR' ? user.doctorId : null],
  );
  return rows;
});

// The partial unique indexes stop a bed or patient being in two open admissions.
export const POST = route(['ADMIN', 'RECEPTIONIST'], async ({ db, body }) => {
  const bed = await db.query("SELECT 1 FROM bed WHERE bed_id = $1 AND status = 'AVAILABLE' FOR UPDATE", [body.bed_id]);
  if (bed.rows.length === 0) throw new ApiError(400, 'That bed is not available.');
  await db.query(
    'INSERT INTO admission (patient_id, doctor_id, bed_id, reason) VALUES ($1, $2, $3, $4)',
    [body.patient_id, body.doctor_id, body.bed_id, body.reason],
  );
});
