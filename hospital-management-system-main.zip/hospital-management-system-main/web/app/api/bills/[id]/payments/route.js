import { route } from '@/lib/route';

// The triggers on payment reject overpayment and update the bill's status.
export const POST = route(['ADMIN', 'RECEPTIONIST'], async ({ db, params, body }) => {
  await db.query('INSERT INTO payment (bill_id, amount, method) VALUES ($1, $2, $3)', [params.id, body.amount, body.method]);
});
