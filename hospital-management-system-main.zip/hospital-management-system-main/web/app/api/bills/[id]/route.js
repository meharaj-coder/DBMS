import { route } from '@/lib/route';

export const GET = route(['ADMIN', 'RECEPTIONIST'], async ({ db, params }) => {
  const items = await db.query(
    'SELECT item_no, description, quantity, unit_price, quantity * unit_price AS amount FROM bill_item WHERE bill_id = $1 ORDER BY item_no',
    [params.id],
  );
  const payments = await db.query('SELECT payment_id, amount, method, paid_on FROM payment WHERE bill_id = $1 ORDER BY paid_on', [params.id]);
  return { items: items.rows, payments: payments.rows };
});
