import { route } from '@/lib/route';

export const GET = route(['ADMIN', 'RECEPTIONIST'], async ({ db }) => {
  const { rows } = await db.query('SELECT * FROM v_bill ORDER BY bill_date DESC, bill_id DESC');
  return rows;
});
