import { NextResponse } from 'next/server';
import { pool } from '@/lib/db';
import { COOKIE_NAME, createToken } from '@/lib/auth';

export async function POST(request) {
  const { username, password } = await request.json();

  // crypt() hashes the entered password with the salt stored in password_hash.
  const { rows } = await pool.query(
    `SELECT user_id, username, role, doctor_id
     FROM   user_account
     WHERE  username = $1 AND password_hash = crypt($2, password_hash)`,
    [username, password],
  );
  if (rows.length === 0) {
    return NextResponse.json({ error: 'Wrong username or password.' }, { status: 401 });
  }

  const u = rows[0];
  const token = await createToken({ userId: u.user_id, username: u.username, role: u.role, doctorId: u.doctor_id });

  const response = NextResponse.json({ ok: true });
  response.cookies.set(COOKIE_NAME, token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: request.nextUrl.protocol === 'https:',   // plain http://localhost must still work
    path: '/',
    maxAge: 8 * 60 * 60,
  });
  return response;
}
