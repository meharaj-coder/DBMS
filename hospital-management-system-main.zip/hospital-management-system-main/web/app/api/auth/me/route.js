import { NextResponse } from 'next/server';
import { getUser } from '@/lib/auth';

// Tells the pages who is signed in, so they can show the right buttons.
// The real access checks happen in the API routes and in the database.
export async function GET() {
  const user = await getUser();
  if (!user) return NextResponse.json({ error: 'Please log in.' }, { status: 401 });
  return NextResponse.json({ username: user.username, role: user.role });
}
