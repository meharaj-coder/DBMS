import { route } from '@/lib/route';

const ALL = ['ADMIN', 'DOCTOR', 'RECEPTIONIST', 'PHARMACIST'];

// Each role sees counts from the tables it is allowed to read.
const STATS = {
  ADMIN: {
    Patients: 'SELECT COUNT(*) FROM patient',
    "Today's appointments": 'SELECT COUNT(*) FROM appointment WHERE appointment_date = CURRENT_DATE',
    'Beds occupied': "SELECT COUNT(*) FROM bed WHERE status = 'OCCUPIED'",
    'Bills not fully paid': "SELECT COUNT(*) FROM bill WHERE status <> 'PAID'",
    'Medicines to reorder': 'SELECT COUNT(*) FROM v_stock WHERE on_hand < reorder_level',
  },
  RECEPTIONIST: {
    Patients: 'SELECT COUNT(*) FROM patient',
    "Today's appointments": 'SELECT COUNT(*) FROM appointment WHERE appointment_date = CURRENT_DATE',
    'Available beds': "SELECT COUNT(*) FROM bed WHERE status = 'AVAILABLE'",
    'Bills not fully paid': "SELECT COUNT(*) FROM bill WHERE status <> 'PAID'",
  },
  DOCTOR: {
    "Today's appointments": 'SELECT COUNT(*) FROM appointment WHERE doctor_id = $1 AND appointment_date = CURRENT_DATE',
    'Upcoming appointments': "SELECT COUNT(*) FROM appointment WHERE doctor_id = $1 AND appointment_date > CURRENT_DATE AND status = 'SCHEDULED'",
    'My in-patients': 'SELECT COUNT(*) FROM admission WHERE doctor_id = $1 AND discharged_on IS NULL',
  },
  PHARMACIST: {
    'Prescriptions to dispense': 'SELECT COUNT(*) FROM v_pending_prescription',
    'Medicines to reorder': 'SELECT COUNT(*) FROM v_stock WHERE on_hand < reorder_level',
  },
};

export const GET = route(ALL, async ({ db, user }) => {
  const stats = [];
  for (const [label, sql] of Object.entries(STATS[user.role])) {
    const params = user.role === 'DOCTOR' ? [user.doctorId] : [];
    const { rows } = await db.query(sql, params);
    stats.push({ label, value: rows[0].count });
  }
  return stats;
});
