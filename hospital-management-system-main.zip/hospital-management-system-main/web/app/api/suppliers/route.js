import { route } from '@/lib/route';

export const GET = route(['ADMIN', 'PHARMACIST'], async ({ db }) => {
  const { rows } = await db.query('SELECT supplier_id, name FROM supplier ORDER BY name');
  return rows;
});
