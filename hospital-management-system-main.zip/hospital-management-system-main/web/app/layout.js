import './globals.css';
import { getUser } from '@/lib/auth';
import Sidebar from '@/components/Sidebar';

export const metadata = { title: 'Hospital Management System' };

export default async function RootLayout({ children }) {
  const user = await getUser();
  return (
    <html lang="en">
      <body>
        {user ? (
          <div className="app">
            <Sidebar user={{ username: user.username, role: user.role }} />
            <main>{children}</main>
          </div>
        ) : children}
      </body>
    </html>
  );
}
