'use client';
import { useState } from 'react';
import { api, Form, Message, Status, Table, money, useData } from '@/components/ui';

export default function BillingPage() {
  const [bills, reloadBills, error] = useData('/api/bills');
  const [selected, setSelected] = useState(null);
  const [detail, reloadDetail] = useData(selected ? `/api/bills/${selected.bill_id}` : null);

  const bill = selected && bills?.find((b) => b.bill_id === selected.bill_id);

  return (
    <>
      <h2>Billing</h2>
      {bill && (
        <div className="card">
          <h3>Bill #{bill.bill_id} - {bill.patient_name}</h3>
          <Table
            rows={detail?.items}
            columns={[
              { key: 'description', label: 'Item' },
              { key: 'quantity', label: 'Qty' },
              { label: 'Unit price', render: (i) => money(i.unit_price) },
              { label: 'Amount', render: (i) => money(i.amount) },
            ]}
          />
          <p>Total {money(bill.total)} | Insurance {money(bill.insurance)} | <b>Due {money(bill.due)}</b></p>
          {bill.due > 0 && (
            <Form
              submitLabel="Record payment"
              fields={[
                { name: 'amount', label: 'Amount', type: 'number', min: 0.01, step: '0.01', required: true },
                { name: 'method', label: 'Method', required: true, options: ['CASH', 'CARD', 'UPI'].map((m) => ({ value: m, label: m })) },
              ]}
              onSubmit={async (v) => { await api(`/api/bills/${bill.bill_id}/payments`, 'POST', v); reloadBills(); reloadDetail(); }}
            />
          )}
        </div>
      )}
      <div className="card">
        <Message error={error} />
        <Table
          rowKey="bill_id"
          rows={bills}
          columns={[
            { key: 'bill_id', label: '#' },
            { key: 'bill_date', label: 'Date' },
            { key: 'patient_name', label: 'Patient' },
            { label: 'Total', render: (b) => money(b.total) },
            { label: 'Insurance', render: (b) => money(b.insurance) },
            { label: 'Due', render: (b) => money(b.due) },
            { label: 'Status', render: (b) => <Status value={b.status} /> },
            { label: '', render: (b) => <button className="btn btn-small btn-light" onClick={() => setSelected(b)}>Open</button> },
          ]}
        />
      </div>
    </>
  );
}
