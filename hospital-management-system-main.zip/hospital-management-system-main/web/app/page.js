'use client';
import { Message, useData } from '@/components/ui';

export default function Dashboard() {
  const [stats, , error] = useData('/api/dashboard');
  return (
    <>
      <h2>Dashboard</h2>
      <Message error={error} />
      <div className="stats">
        {stats?.map((s) => (
          <div className="stat" key={s.label}><b>{s.value}</b>{s.label}</div>
        ))}
      </div>
    </>
  );
}
