'use client';
import { useState } from 'react';
import { api, Form, Message, Status, Table, useData } from '@/components/ui';

export default function AdmissionsPage() {
  const [admissions, reloadAdmissions, error] = useData('/api/admissions');
  const [beds, reloadBeds] = useData('/api/beds');
  const [patients] = useData('/api/patients');
  const [doctors] = useData('/api/doctors');
  const [me] = useData('/api/auth/me');
  const [actionError, setActionError] = useState('');
  const canManage = me?.role === 'ADMIN' || me?.role === 'RECEPTIONIST';

  const reload = () => { reloadAdmissions(); reloadBeds(); };

  async function discharge(id) {
    setActionError('');
    try {
      await api(`/api/admissions/${id}/discharge`, 'POST', {});
      reload();
    } catch (err) {
      setActionError(err.message);
    }
  }

  const fields = [
    { name: 'patient_id', label: 'Patient', required: true, options: (patients || []).map((p) => ({ value: p.patient_id, label: `${p.first_name} ${p.last_name}` })) },
    { name: 'doctor_id', label: 'Supervising doctor', required: true, options: (doctors || []).map((d) => ({ value: d.doctor_id, label: `Dr. ${d.first_name} ${d.last_name}` })) },
    { name: 'bed_id', label: 'Bed', required: true, options: (beds || []).filter((b) => b.status === 'AVAILABLE').map((b) => ({ value: b.bed_id, label: `${b.ward} ${b.bed_no}` })) },
    { name: 'reason', label: 'Reason' },
  ];

  return (
    <>
      <h2>Admissions</h2>
      {canManage && (
        <div className="card">
          <h3>Admit a patient</h3>
          <Form fields={fields} submitLabel="Admit" onSubmit={async (v) => { await api('/api/admissions', 'POST', v); reload(); }} />
        </div>
      )}
      <div className="card">
        <h3>Admissions</h3>
        <Message error={error || actionError} />
        <Table
          rowKey="admission_id"
          rows={admissions}
          columns={[
            { key: 'patient_name', label: 'Patient' },
            { key: 'doctor_name', label: 'Doctor' },
            { label: 'Bed', render: (a) => `${a.ward} ${a.bed_no}` },
            { key: 'admitted_on', label: 'Admitted' },
            { label: 'Discharged', render: (a) => a.discharged_on || 'In hospital' },
            { key: 'reason', label: 'Reason' },
            { label: '', render: (a) => canManage && !a.discharged_on && <button className="btn btn-small" onClick={() => discharge(a.admission_id)}>Discharge</button> },
          ]}
        />
      </div>
      <div className="card">
        <h3>Beds</h3>
        <Table
          rowKey="bed_id"
          rows={beds}
          columns={[
            { key: 'ward', label: 'Ward' },
            { key: 'bed_no', label: 'Bed' },
            { key: 'daily_rate', label: 'Daily rate' },
            { label: 'Status', render: (b) => <Status value={b.status} /> },
          ]}
        />
      </div>
    </>
  );
}
