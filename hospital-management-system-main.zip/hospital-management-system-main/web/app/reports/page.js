'use client';
import { Message, Table, money, useData } from '@/components/ui';

export default function ReportsPage() {
  const [data, , error] = useData('/api/reports');
  return (
    <>
      <h2>Reports</h2>
      <Message error={error} />
      <div className="card">
        <h3>Monthly revenue</h3>
        <Table
          rows={data?.revenue}
          columns={[
            { label: 'Month', render: (r) => r.month.slice(0, 7) },
            { label: 'Collected', render: (r) => money(r.collected) },
            { label: 'Running total', render: (r) => money(r.running_total) },
            { label: 'Change from last month', render: (r) => money(r.change_from_last_month) },
          ]}
        />
      </div>
      <div className="two-col">
        <div className="card">
          <h3>Doctor ranking by department</h3>
          <Table
            rows={data?.ranking}
            columns={[
              { key: 'department', label: 'Department' },
              { key: 'doctor_name', label: 'Doctor' },
              { key: 'completed', label: 'Completed' },
              { key: 'rank_in_department', label: 'Rank' },
            ]}
          />
        </div>
        <div>
          <div className="card">
            <h3>Bed occupancy</h3>
            <Table
              rows={data?.occupancy}
              columns={[
                { key: 'ward', label: 'Ward' },
                { key: 'total_beds', label: 'Beds' },
                { key: 'occupied', label: 'Occupied' },
                { label: 'Occupancy', render: (r) => `${r.occupancy_percent}%` },
              ]}
            />
          </div>
          <div className="card">
            <h3>Patients billed above average</h3>
            <Table
              rows={data?.topPatients}
              columns={[
                { key: 'patient_name', label: 'Patient' },
                { label: 'Total billed', render: (r) => money(r.total_billed) },
              ]}
            />
          </div>
        </div>
      </div>
    </>
  );
}
