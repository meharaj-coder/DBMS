'use client';
import { useState } from 'react';
import { api, Form, Message, Table, useData } from '@/components/ui';

const FIELDS = [
  { name: 'first_name', label: 'First name', required: true },
  { name: 'last_name', label: 'Last name', required: true },
  { name: 'date_of_birth', label: 'Date of birth', type: 'date', required: true },
  { name: 'gender', label: 'Gender', required: true, options: [{ value: 'M', label: 'Male' }, { value: 'F', label: 'Female' }, { value: 'O', label: 'Other' }] },
  { name: 'blood_group', label: 'Blood group', options: ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'].map((b) => ({ value: b, label: b })) },
  { name: 'phone', label: 'Add phone number' },
  { name: 'street', label: 'Street' },
  { name: 'city', label: 'City' },
  { name: 'state', label: 'State' },
  { name: 'zip', label: 'PIN code' },
];

export default function PatientsPage() {
  const [search, setSearch] = useState('');
  const [patients, reload, error] = useData(`/api/patients?q=${encodeURIComponent(search)}`);
  const [editing, setEditing] = useState(null);
  const [me] = useData('/api/auth/me');
  const [actionError, setActionError] = useState('');
  const canEdit = me?.role === 'ADMIN' || me?.role === 'RECEPTIONIST';

  async function save(values) {
    if (editing) await api(`/api/patients/${editing.patient_id}`, 'PUT', values);
    else await api('/api/patients', 'POST', values);
    setEditing(null);
    reload();
  }

  async function remove(p) {
    if (!confirm(`Delete ${p.first_name} ${p.last_name}?`)) return;
    setActionError('');
    try {
      await api(`/api/patients/${p.patient_id}`, 'DELETE');
      reload();
    } catch (err) {
      setActionError(err.message);
    }
  }

  const columns = [
    { key: 'patient_id', label: 'ID' },
    { label: 'Name', render: (p) => `${p.first_name} ${p.last_name}` },
    { key: 'age', label: 'Age' },
    { key: 'gender', label: 'Gender' },
    { key: 'blood_group', label: 'Blood' },
    { key: 'phones', label: 'Phone' },
    { key: 'city', label: 'City' },
    { key: 'registered_on', label: 'Registered' },
  ];
  if (canEdit) {
    columns.push({
      label: 'Actions',
      render: (p) => (
        <>
          <button className="btn btn-small btn-light" onClick={() => setEditing(p)}>Edit</button>
          <button className="btn btn-small btn-danger" onClick={() => remove(p)}>Delete</button>
        </>
      ),
    });
  }

  return (
    <>
      <h2>Patients</h2>
      {canEdit && (
        <div className="card">
          <h3>{editing ? `Edit patient #${editing.patient_id}` : 'Register a patient'}</h3>
          <Form fields={FIELDS} onSubmit={save} initial={editing} submitLabel={editing ? 'Update' : 'Register'} />
          {editing && <button className="btn btn-light" style={{ marginTop: 8 }} onClick={() => setEditing(null)}>Cancel edit</button>}
        </div>
      )}
      <div className="card">
        <div className="searchbar">
          <input placeholder="Search by name" value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
        <Message error={error || actionError} />
        <Table columns={columns} rows={patients} rowKey="patient_id" />
      </div>
    </>
  );
}
