import { NextResponse } from 'next/server';
import { COOKIE_NAME, verifyToken } from './lib/auth';

// Sends anyone who is not logged in to the login page. The API routes do their
// own check in lib/route.js, so they are not covered here.
export async function proxy(request) {
  const token = request.cookies.get(COOKIE_NAME)?.value;
  const user = token ? await verifyToken(token) : null;
  if (!user) return NextResponse.redirect(new URL('/login', request.url));
  return NextResponse.next();
}

export const config = { matcher: ['/((?!api|login|_next|favicon.ico).*)'] };
