const nextConfig = {
  serverExternalPackages: ['pg', 'neo4j-driver'],
  devIndicators: false,
};
export default nextConfig;
