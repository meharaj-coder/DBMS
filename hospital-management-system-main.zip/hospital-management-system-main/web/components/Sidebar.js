'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';

const LINKS = [
  { href: '/', label: 'Dashboard', roles: ['ADMIN', 'DOCTOR', 'RECEPTIONIST', 'PHARMACIST'] },
  { href: '/patients', label: 'Patients', roles: ['ADMIN', 'DOCTOR', 'RECEPTIONIST'] },
  { href: '/doctors', label: 'Doctors', roles: ['ADMIN', 'DOCTOR', 'RECEPTIONIST'] },
  { href: '/appointments', label: 'Appointments', roles: ['ADMIN', 'DOCTOR', 'RECEPTIONIST'] },
  { href: '/prescriptions', label: 'Prescriptions', roles: ['ADMIN', 'DOCTOR'] },
  { href: '/admissions', label: 'Admissions', roles: ['ADMIN', 'DOCTOR', 'RECEPTIONIST'] },
  { href: '/billing', label: 'Billing', roles: ['ADMIN', 'RECEPTIONIST'] },
  { href: '/pharmacy', label: 'Pharmacy', roles: ['ADMIN', 'PHARMACIST'] },
  { href: '/interactions', label: 'Drug Interactions', roles: ['ADMIN', 'DOCTOR', 'PHARMACIST'] },
  { href: '/reports', label: 'Reports', roles: ['ADMIN'] },
];

export default function Sidebar({ user }) {
  const pathname = usePathname();

  async function logout() {
    await fetch('/api/auth/logout', { method: 'POST' });
    window.location.href = '/login';
  }

  return (
    <aside className="sidebar">
      <h1>Hospital Management</h1>
      <nav>
        {LINKS.filter((l) => l.roles.includes(user.role)).map((l) => (
          <Link key={l.href} href={l.href} className={pathname === l.href ? 'active' : ''}>{l.label}</Link>
        ))}
      </nav>
      <div className="user">
        <strong>{user.username}</strong>
        <span>{user.role}</span>
        <button className="btn btn-small btn-light" onClick={logout}>Log out</button>
      </div>
    </aside>
  );
}
