'use client';
import { useCallback, useEffect, useState } from 'react';

// Calls an API route and throws the server's message if it failed.
export async function api(url, method = 'GET', body) {
  const res = await fetch(url, {
    method,
    headers: body ? { 'Content-Type': 'application/json' } : undefined,
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}

// Loads data from a URL. Returns the data, a reload function and any error.
export function useData(url) {
  const [data, setData] = useState(null);
  const [error, setError] = useState('');
  const reload = useCallback(() => {
    if (!url) return setData(null);
    api(url).then((d) => { setData(d); setError(''); }).catch((e) => setError(e.message));
  }, [url]);
  useEffect(reload, [reload]);
  return [data, reload, error];
}

export function Message({ error, success }) {
  if (error) return <p className="msg msg-error">{error}</p>;
  if (success) return <p className="msg msg-success">{success}</p>;
  return null;
}

// columns: [{ key, label, render? }]
export function Table({ columns, rows, rowKey, empty = 'Nothing to show.' }) {
  if (!rows) return null;   // still loading, or the page is showing an error
  if (rows.length === 0) return <p className="muted">{empty}</p>;
  return (
    <div className="table-wrap">
      <table>
        <thead>
          <tr>{columns.map((c) => <th key={c.label}>{c.label}</th>)}</tr>
        </thead>
        <tbody>
          {rows.map((row, i) => (
            <tr key={rowKey ? row[rowKey] : i}>
              {columns.map((c) => <td key={c.label}>{c.render ? c.render(row) : row[c.key]}</td>)}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// A form built from a list of fields:
// [{ name, label, type?, options?: [{ value, label }], required?, min? }]
export function Form({ fields, onSubmit, submitLabel = 'Save', initial, onChange }) {
  const [values, setValues] = useState(initial || {});
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => { setValues(initial || {}); }, [initial]);

  function set(name, value) {
    const next = { ...values, [name]: value };
    setValues(next);
    onChange?.(next);
  }

  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      await onSubmit(values);
      setValues({});
      onChange?.({});
    } catch (err) {
      setError(err.message);
    }
    setBusy(false);
  }

  return (
    <form onSubmit={submit}>
      <div className="form-grid">
        {fields.map((f) => (
          <label key={f.name}>
            {f.label}
            {f.options ? (
              <select required={f.required} value={values[f.name] ?? ''} onChange={(e) => set(f.name, e.target.value)}>
                <option value="">Select...</option>
                {f.options.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
              </select>
            ) : (
              <input
                type={f.type || 'text'} required={f.required} min={f.min} step={f.step}
                value={values[f.name] ?? ''} onChange={(e) => set(f.name, e.target.value)}
              />
            )}
          </label>
        ))}
      </div>
      <Message error={error} />
      <button className="btn" disabled={busy}>{busy ? 'Saving...' : submitLabel}</button>
    </form>
  );
}

export const Status = ({ value }) => <span className={`badge badge-${value}`}>{value}</span>;
export const money = (n) => {
  if (n === null || n === undefined) return '-';
  return `${n < 0 ? '-' : ''}₹${Math.abs(Number(n)).toFixed(2)}`;
};
