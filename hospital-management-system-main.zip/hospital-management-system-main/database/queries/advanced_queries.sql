-- Queries for the SQL rubric items.

\echo === JOIN: upcoming appointments with patient, doctor and department ===
SELECT a.appointment_date, a.start_time, p.first_name || ' ' || p.last_name AS patient,
       d.last_name AS doctor, dp.name AS department
FROM   appointment a
JOIN   patient p     ON p.patient_id = a.patient_id
JOIN   doctor d      ON d.doctor_id = a.doctor_id
JOIN   department dp ON dp.department_id = d.department_id
WHERE  a.status = 'SCHEDULED'
ORDER  BY a.appointment_date, a.start_time;

\echo === LEFT JOIN + aggregate: appointments per department, including empty ones ===
SELECT dp.name AS department, COUNT(a.appointment_id) AS appointments
FROM   department dp
LEFT JOIN doctor d ON d.department_id = dp.department_id
LEFT JOIN appointment a ON a.doctor_id = d.doctor_id
GROUP  BY dp.name
ORDER  BY appointments DESC;

\echo === NESTED: medicines that have never been prescribed ===
SELECT name FROM medicine
WHERE  medicine_id NOT IN (SELECT medicine_id FROM prescription_medicine);

\echo === NESTED: doctors charging more than the average fee ===
SELECT first_name, last_name, consultation_fee FROM doctor
WHERE  consultation_fee > (SELECT AVG(consultation_fee) FROM doctor)
ORDER  BY consultation_fee DESC;

\echo === CORRELATED: each doctor's most recent completed appointment ===
SELECT d.last_name AS doctor, a.appointment_date, a.reason
FROM   appointment a JOIN doctor d ON d.doctor_id = a.doctor_id
WHERE  a.status = 'COMPLETED'
  AND  a.appointment_date = (SELECT MAX(a2.appointment_date) FROM appointment a2
                             WHERE  a2.doctor_id = a.doctor_id AND a2.status = 'COMPLETED');

\echo === CORRELATED with EXISTS: patients who have an appointment and an admission ===
SELECT p.first_name, p.last_name FROM patient p
WHERE  EXISTS (SELECT 1 FROM appointment a WHERE a.patient_id = p.patient_id)
  AND  EXISTS (SELECT 1 FROM admission ad WHERE ad.patient_id = p.patient_id);

\echo === SET OPERATION: patients with an admission but no future appointment (EXCEPT) ===
SELECT patient_id FROM admission
EXCEPT
SELECT patient_id FROM appointment WHERE status = 'SCHEDULED';

\echo === SET OPERATION: one patient timeline from two tables (UNION ALL) ===
SELECT appointment_date AS event_date, 'Appointment' AS event, reason FROM appointment WHERE patient_id = 2
UNION ALL
SELECT admitted_on, 'Admission', reason FROM admission WHERE patient_id = 2
ORDER  BY event_date;

\echo === RECURSIVE CTE: every 20-minute slot in a 9 to 12 session ===
WITH RECURSIVE slots AS (
    SELECT TIME '09:00' AS slot_time
  UNION ALL
    SELECT (slot_time + INTERVAL '20 minutes')::TIME FROM slots
    WHERE  slot_time < TIME '11:40'
)
SELECT slot_time FROM slots;

\echo === RECURSIVE CTE inside a function: free slots for Dr. Menon tomorrow ===
SELECT * FROM fn_available_slots(2, (CURRENT_DATE + 1)::DATE);

\echo === CTE + AGGREGATE: patients billed above average ===
WITH patient_totals AS (
    SELECT patient_id, SUM(fn_bill_total(bill_id)) AS billed FROM bill GROUP BY patient_id
)
SELECT p.first_name, p.last_name, t.billed
FROM   patient_totals t JOIN patient p ON p.patient_id = t.patient_id
WHERE  t.billed > (SELECT AVG(billed) FROM patient_totals)
ORDER  BY t.billed DESC;

\echo === WINDOW FUNCTIONS: monthly revenue with running total ===
SELECT * FROM v_monthly_revenue ORDER BY month;

\echo === WINDOW FUNCTIONS: doctor ranking inside each department ===
SELECT * FROM v_doctor_ranking ORDER BY department, rank_in_department;

\echo === FULL-TEXT SEARCH: diagnoses matching "fever" ===
SELECT prescription_id, diagnosis,
       ts_rank(to_tsvector('english', diagnosis), plainto_tsquery('english', 'fever')) AS rank
FROM   prescription
WHERE  to_tsvector('english', diagnosis) @@ plainto_tsquery('english', 'fever')
ORDER  BY rank DESC;

\echo === VIEW: medicines below their reorder level ===
SELECT name, on_hand, reorder_level, supplier FROM v_stock WHERE on_hand < reorder_level;

\echo === QUERY OPTIMIZATION: the plan for a full-text search ===
SET enable_seqscan = off;    -- this table is small, so force the planner to show the index
EXPLAIN SELECT prescription_id FROM prescription
WHERE to_tsvector('english', diagnosis) @@ plainto_tsquery('english', 'fever');
RESET enable_seqscan;
