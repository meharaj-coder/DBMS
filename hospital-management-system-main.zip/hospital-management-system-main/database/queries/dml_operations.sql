-- DML demonstration. Everything runs inside one transaction and is rolled back
-- at the end, so the sample data stays as it was.
BEGIN;

-- INSERT
INSERT INTO patient (first_name, last_name, date_of_birth, gender, blood_group, city, state, zip)
VALUES ('Rahul', 'Bose', '1990-05-15', 'M', 'B+', 'Bengaluru', 'Karnataka', '560085');

INSERT INTO patient_phone (patient_id, phone_no)
SELECT patient_id, '9886099999' FROM patient WHERE first_name = 'Rahul' AND last_name = 'Bose';

SELECT patient_id, first_name, last_name, age, phones FROM v_patient WHERE last_name = 'Bose';

-- UPDATE
UPDATE medicine SET unit_price = unit_price * 1.10 WHERE name = 'Paracetamol 500 mg';
SELECT name, unit_price FROM medicine WHERE name = 'Paracetamol 500 mg';

-- DELETE
DELETE FROM patient_phone WHERE phone_no = '9886099999';
DELETE FROM patient WHERE last_name = 'Bose';
SELECT COUNT(*) AS patients_named_bose FROM patient WHERE last_name = 'Bose';

-- A constraint rejecting bad data (the savepoint keeps the transaction usable afterwards).
SAVEPOINT before_bad_insert;
INSERT INTO bed (ward, bed_no, daily_rate) VALUES ('ICU', 'I-03', -500);
ROLLBACK TO before_bad_insert;

-- Trigger 1 rejecting an overpayment.
SAVEPOINT before_overpayment;
INSERT INTO payment (bill_id, amount, method) VALUES (9, 99999, 'CASH');
ROLLBACK TO before_overpayment;

-- Trigger 2 changing a bill from UNPAID to PARTIAL.
SELECT bill_id, status FROM bill WHERE bill_id = 9;
INSERT INTO payment (bill_id, amount, method) VALUES (9, 300, 'UPI');
SELECT bill_id, status FROM bill WHERE bill_id = 9;

-- Procedure and trigger 3: discharge frees the bed and creates a bill.
SELECT bed_no, status FROM bed WHERE bed_no = 'I-01';
CALL sp_discharge_patient(2);
SELECT bed_no, status FROM bed WHERE bed_no = 'I-01';
SELECT * FROM v_bill WHERE patient_name = 'Vivaan Shetty' ORDER BY bill_id DESC LIMIT 1;

ROLLBACK;
