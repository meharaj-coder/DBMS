-- Shows PostgreSQL enforcing the roles. Run through the hms_app login role,
-- which is what the web application uses. Errors here are the expected result.

\echo === hms_app on its own has no access to hospital data ===
SELECT * FROM patient LIMIT 1;

\echo === Receptionist can read patients ===
BEGIN; SET LOCAL ROLE hms_receptionist;
SELECT patient_id, first_name, last_name FROM patient LIMIT 2;
COMMIT;

\echo === Receptionist cannot read diagnoses ===
BEGIN; SET LOCAL ROLE hms_receptionist;
SELECT diagnosis FROM prescription LIMIT 1;
ROLLBACK;

\echo === Doctor can read diagnoses ===
BEGIN; SET LOCAL ROLE hms_doctor;
SELECT prescription_id, diagnosis FROM prescription LIMIT 2;
COMMIT;

\echo === Doctor cannot read bills ===
BEGIN; SET LOCAL ROLE hms_doctor;
SELECT * FROM bill LIMIT 1;
ROLLBACK;

\echo === Pharmacist can see what to dispense, without the diagnosis ===
BEGIN; SET LOCAL ROLE hms_pharmacist;
SELECT * FROM v_pending_prescription LIMIT 1;
COMMIT;

\echo === Pharmacist cannot read the patient table ===
BEGIN; SET LOCAL ROLE hms_pharmacist;
SELECT * FROM patient LIMIT 1;
ROLLBACK;

\echo === Pharmacist cannot run a receptionist procedure ===
BEGIN; SET LOCAL ROLE hms_pharmacist;
CALL sp_discharge_patient(2);
ROLLBACK;

\echo === Which privileges each role has on selected tables ===
SELECT grantee, table_name, STRING_AGG(privilege_type, ', ' ORDER BY privilege_type) AS privileges
FROM   information_schema.role_table_grants
WHERE  grantee LIKE 'hms_%' AND table_name IN ('patient', 'prescription', 'bill', 'stock_batch')
GROUP  BY grantee, table_name
ORDER  BY table_name, grantee;
