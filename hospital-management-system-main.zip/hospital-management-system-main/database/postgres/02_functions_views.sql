-- Functions and views.

-- Free slots for a doctor on a date. The recursive CTE steps through the
-- doctor's working hours; booked slots are then removed with NOT EXISTS.
CREATE FUNCTION fn_available_slots(p_doctor_id INT, p_date DATE)
RETURNS TABLE (slot_time TIME)
LANGUAGE sql STABLE AS $$
    WITH RECURSIVE slots AS (
        SELECT start_time AS slot_time, end_time, slot_minutes
        FROM   schedule
        WHERE  doctor_id = p_doctor_id AND day_of_week = EXTRACT(DOW FROM p_date)
      UNION ALL
        SELECT (slot_time + make_interval(mins => slot_minutes))::TIME, end_time, slot_minutes
        FROM   slots
        WHERE  slot_time + make_interval(mins => slot_minutes * 2) <= end_time
    )
    SELECT s.slot_time
    FROM   slots s
    WHERE  NOT EXISTS (
        SELECT 1 FROM appointment a
        WHERE  a.doctor_id = p_doctor_id AND a.appointment_date = p_date
          AND  a.start_time = s.slot_time AND a.status <> 'CANCELLED')
    ORDER  BY s.slot_time;
$$;

CREATE FUNCTION fn_bill_total(p_bill_id INT) RETURNS NUMERIC
LANGUAGE sql STABLE AS $$
    SELECT COALESCE(SUM(quantity * unit_price), 0) FROM bill_item WHERE bill_id = p_bill_id;
$$;

-- Insurance pays a percentage of the bill, up to the policy's limit.
CREATE FUNCTION fn_bill_insurance(p_bill_id INT) RETURNS NUMERIC
LANGUAGE sql STABLE AS $$
    SELECT COALESCE((
        SELECT LEAST(ROUND(fn_bill_total(b.bill_id) * p.coverage_percent / 100, 2), p.max_coverage)
        FROM   bill b JOIN policy p ON p.policy_id = b.policy_id
        WHERE  b.bill_id = p_bill_id), 0);
$$;

-- What the patient still has to pay.
CREATE FUNCTION fn_bill_due(p_bill_id INT) RETURNS NUMERIC
LANGUAGE sql STABLE AS $$
    SELECT fn_bill_total(p_bill_id) - fn_bill_insurance(p_bill_id)
         - COALESCE((SELECT SUM(amount) FROM payment WHERE bill_id = p_bill_id), 0);
$$;

-- Derived attribute: age.
CREATE VIEW v_patient AS
SELECT p.*,
       EXTRACT(YEAR FROM AGE(p.date_of_birth))::INT AS age,
       (SELECT STRING_AGG(ph.phone_no, ', ') FROM patient_phone ph WHERE ph.patient_id = p.patient_id) AS phones
FROM   patient p;

-- Derived attribute: experience.
CREATE VIEW v_doctor AS
SELECT d.*, dp.name AS department,
       EXTRACT(YEAR FROM AGE(d.joining_date))::INT AS experience_years
FROM   doctor d JOIN department dp ON dp.department_id = d.department_id;

CREATE VIEW v_appointment AS
SELECT a.*,
       p.first_name || ' ' || p.last_name AS patient_name,
       'Dr. ' || d.first_name || ' ' || d.last_name AS doctor_name
FROM   appointment a
JOIN   patient p ON p.patient_id = a.patient_id
JOIN   doctor d  ON d.doctor_id = a.doctor_id;

CREATE VIEW v_admission AS
SELECT ad.*,
       p.first_name || ' ' || p.last_name AS patient_name,
       'Dr. ' || d.first_name || ' ' || d.last_name AS doctor_name,
       b.ward, b.bed_no
FROM   admission ad
JOIN   patient p ON p.patient_id = ad.patient_id
JOIN   doctor d  ON d.doctor_id = ad.doctor_id
JOIN   bed b     ON b.bed_id = ad.bed_id;

CREATE VIEW v_bill AS
SELECT b.bill_id, b.bill_date, b.status,
       p.first_name || ' ' || p.last_name AS patient_name,
       fn_bill_total(b.bill_id)     AS total,
       fn_bill_insurance(b.bill_id) AS insurance,
       fn_bill_due(b.bill_id)       AS due
FROM   bill b JOIN patient p ON p.patient_id = b.patient_id;

-- Stock that has not expired, compared with the reorder level.
CREATE VIEW v_stock AS
SELECT m.medicine_id, m.name, m.unit_price, m.reorder_level, s.name AS supplier,
       COALESCE(SUM(b.quantity) FILTER (WHERE b.expiry_date > CURRENT_DATE), 0)::INT AS on_hand,
       MIN(b.expiry_date) FILTER (WHERE b.expiry_date > CURRENT_DATE AND b.quantity > 0) AS next_expiry
FROM   medicine m
JOIN   supplier s ON s.supplier_id = m.supplier_id
LEFT JOIN stock_batch b ON b.medicine_id = m.medicine_id
GROUP  BY m.medicine_id, m.name, m.unit_price, m.reorder_level, s.name;

-- What the pharmacist needs to fill a prescription. The diagnosis is left out on purpose.
CREATE VIEW v_pending_prescription AS
SELECT r.prescription_id, r.prescribed_on,
       p.first_name || ' ' || p.last_name AS patient_name,
       'Dr. ' || d.first_name || ' ' || d.last_name AS doctor_name,
       a.status AS appointment_status,
       STRING_AGG(m.name || ' x ' || pm.quantity, ', ' ORDER BY m.name) AS medicines
FROM   prescription r
JOIN   appointment a ON a.appointment_id = r.appointment_id
JOIN   patient p ON p.patient_id = a.patient_id
JOIN   doctor d  ON d.doctor_id = a.doctor_id
JOIN   prescription_medicine pm ON pm.prescription_id = r.prescription_id AND NOT pm.dispensed
JOIN   medicine m ON m.medicine_id = pm.medicine_id
GROUP  BY r.prescription_id, r.prescribed_on, p.first_name, p.last_name, d.first_name, d.last_name, a.status;

-- Report: money collected per month with a running total (CTE + window functions).
CREATE VIEW v_monthly_revenue AS
WITH monthly AS (
    SELECT DATE_TRUNC('month', paid_on)::DATE AS month, SUM(amount) AS collected
    FROM   payment
    GROUP  BY 1
)
SELECT month, collected,
       SUM(collected) OVER (ORDER BY month) AS running_total,
       collected - LAG(collected) OVER (ORDER BY month) AS change_from_last_month
FROM   monthly;

-- Report: doctors ranked by completed appointments inside each department.
CREATE VIEW v_doctor_ranking AS
SELECT dp.name AS department,
       'Dr. ' || d.first_name || ' ' || d.last_name AS doctor_name,
       COUNT(a.appointment_id) AS completed,
       RANK() OVER (PARTITION BY dp.department_id ORDER BY COUNT(a.appointment_id) DESC) AS rank_in_department
FROM   doctor d
JOIN   department dp ON dp.department_id = d.department_id
LEFT JOIN appointment a ON a.doctor_id = d.doctor_id AND a.status = 'COMPLETED'
GROUP  BY dp.department_id, dp.name, d.doctor_id, d.first_name, d.last_name;

CREATE VIEW v_bed_occupancy AS
SELECT ward, COUNT(*) AS total_beds,
       COUNT(*) FILTER (WHERE status = 'OCCUPIED') AS occupied,
       ROUND(100.0 * COUNT(*) FILTER (WHERE status = 'OCCUPIED') / COUNT(*), 1) AS occupancy_percent
FROM   bed
GROUP  BY ward;
