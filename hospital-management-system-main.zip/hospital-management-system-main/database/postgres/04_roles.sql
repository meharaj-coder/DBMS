-- Role-based access control inside the database.
-- The web app logs in as hms_app. For each request it runs SET LOCAL ROLE with the
-- signed-in user's role, so PostgreSQL itself refuses anything that role has no
-- GRANT for, even if the application code has a bug.

CREATE ROLE hms_admin        NOLOGIN;
CREATE ROLE hms_doctor       NOLOGIN;
CREATE ROLE hms_receptionist NOLOGIN;
CREATE ROLE hms_pharmacist   NOLOGIN;

-- NOINHERIT: hms_app has none of these rights until it explicitly switches role.
-- Development password; it matches web/.env.example.
CREATE ROLE hms_app LOGIN NOINHERIT PASSWORD 'hms_app_dev';
GRANT hms_admin, hms_doctor, hms_receptionist, hms_pharmacist TO hms_app;
GRANT SELECT ON user_account TO hms_app;   -- needed to check the login

REVOKE EXECUTE ON ALL PROCEDURES IN SCHEMA public FROM PUBLIC;

-- Admin: everything.
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO hms_admin;
GRANT EXECUTE ON ALL PROCEDURES IN SCHEMA public TO hms_admin;

-- Doctor: clinical records. No access to bills or stock.
GRANT SELECT ON department, doctor, schedule, patient, patient_phone, appointment,
                prescription, prescription_medicine, medicine, bed, admission,
                v_patient, v_doctor, v_appointment, v_admission
      TO hms_doctor;
GRANT INSERT ON prescription, prescription_medicine TO hms_doctor;
GRANT EXECUTE ON PROCEDURE sp_complete_appointment(INT) TO hms_doctor;

-- Receptionist: patients, bookings, admissions and billing. Cannot read diagnoses.
GRANT SELECT, INSERT, UPDATE, DELETE ON patient, patient_phone, policy TO hms_receptionist;
GRANT SELECT ON department, doctor, schedule, appointment, v_patient, v_doctor, v_appointment,
                v_admission, v_bill, bill_item, admission, payment
      TO hms_receptionist;
GRANT SELECT, UPDATE ON bed, bill TO hms_receptionist;
GRANT UPDATE (status) ON appointment TO hms_receptionist;
GRANT INSERT ON admission, payment TO hms_receptionist;
GRANT EXECUTE ON PROCEDURE sp_book_appointment(INT, INT, DATE, TIME, VARCHAR),
                           sp_discharge_patient(INT)
      TO hms_receptionist;

-- Pharmacist: stock, and only the medicine details of a prescription.
GRANT SELECT, INSERT, UPDATE, DELETE ON medicine, stock_batch TO hms_pharmacist;
GRANT SELECT ON supplier, v_stock, v_pending_prescription TO hms_pharmacist;
GRANT EXECUTE ON PROCEDURE sp_dispense_prescription(INT) TO hms_pharmacist;
