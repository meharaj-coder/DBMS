-- Hospital Management System: tables, keys and constraints.
-- Composite attributes (name, address) are flattened, multivalued attributes
-- (phone numbers) get their own table, and derived attributes (age, experience)
-- are calculated in views instead of being stored.

ALTER DATABASE hospital SET timezone = 'Asia/Kolkata';
SET timezone = 'Asia/Kolkata';

CREATE EXTENSION IF NOT EXISTS pgcrypto;   -- crypt() and gen_salt() for password hashing

CREATE TABLE department (
    department_id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    name          VARCHAR(60) NOT NULL UNIQUE,
    location      VARCHAR(60) NOT NULL
);

CREATE TABLE doctor (
    doctor_id        INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    department_id    INT          NOT NULL REFERENCES department(department_id),
    first_name       VARCHAR(40)  NOT NULL,
    last_name        VARCHAR(40)  NOT NULL,
    specialization   VARCHAR(60)  NOT NULL,
    email            VARCHAR(100) NOT NULL UNIQUE,
    joining_date     DATE         NOT NULL,
    consultation_fee NUMERIC(8,2) NOT NULL CHECK (consultation_fee >= 0)
);

CREATE TABLE doctor_phone (
    doctor_id INT         NOT NULL REFERENCES doctor(doctor_id) ON DELETE CASCADE,
    phone_no  VARCHAR(15) NOT NULL,
    PRIMARY KEY (doctor_id, phone_no)
);

-- Only DOCTOR accounts link to a doctor row ("Logs in" is 1:1).
CREATE TABLE user_account (
    user_id       INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    username      VARCHAR(40) NOT NULL UNIQUE,
    password_hash TEXT        NOT NULL,
    role          VARCHAR(12) NOT NULL CHECK (role IN ('ADMIN','DOCTOR','RECEPTIONIST','PHARMACIST')),
    doctor_id     INT UNIQUE REFERENCES doctor(doctor_id),
    CHECK ((role = 'DOCTOR') = (doctor_id IS NOT NULL))
);

CREATE TABLE schedule (
    schedule_id  INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    doctor_id    INT      NOT NULL REFERENCES doctor(doctor_id) ON DELETE CASCADE,
    day_of_week  SMALLINT NOT NULL CHECK (day_of_week BETWEEN 0 AND 6),   -- 0 = Sunday
    start_time   TIME     NOT NULL,
    end_time     TIME     NOT NULL,
    slot_minutes SMALLINT NOT NULL DEFAULT 20 CHECK (slot_minutes > 0),
    UNIQUE (doctor_id, day_of_week, start_time),
    CHECK (end_time > start_time)
);

CREATE TABLE patient (
    patient_id    INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    first_name    VARCHAR(40) NOT NULL,
    last_name     VARCHAR(40) NOT NULL,
    date_of_birth DATE        NOT NULL,
    gender        CHAR(1)     NOT NULL CHECK (gender IN ('M','F','O')),
    blood_group   VARCHAR(3)  CHECK (blood_group IN ('A+','A-','B+','B-','AB+','AB-','O+','O-')),
    street        VARCHAR(100),
    city          VARCHAR(50),
    state         VARCHAR(50),
    zip           CHAR(6),
    registered_on DATE        NOT NULL DEFAULT CURRENT_DATE
);

CREATE TABLE patient_phone (
    patient_id INT         NOT NULL REFERENCES patient(patient_id) ON DELETE CASCADE,
    phone_no   VARCHAR(15) NOT NULL,
    PRIMARY KEY (patient_id, phone_no)
);

CREATE TABLE policy (
    policy_id        INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    patient_id       INT           NOT NULL REFERENCES patient(patient_id) ON DELETE CASCADE,
    provider         VARCHAR(60)   NOT NULL,
    policy_no        VARCHAR(30)   NOT NULL UNIQUE,
    coverage_percent NUMERIC(5,2)  NOT NULL CHECK (coverage_percent BETWEEN 0 AND 100),
    max_coverage     NUMERIC(10,2) NOT NULL CHECK (max_coverage >= 0),
    valid_to         DATE          NOT NULL
);

CREATE TABLE appointment (
    appointment_id   INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    patient_id       INT         NOT NULL REFERENCES patient(patient_id),
    doctor_id        INT         NOT NULL REFERENCES doctor(doctor_id),
    appointment_date DATE        NOT NULL,
    start_time       TIME        NOT NULL,
    status           VARCHAR(10) NOT NULL DEFAULT 'SCHEDULED'
                     CHECK (status IN ('SCHEDULED','COMPLETED','CANCELLED','NO_SHOW')),
    reason           VARCHAR(200)
);
-- A doctor cannot have two live bookings in one slot; a cancelled slot can be booked again.
CREATE UNIQUE INDEX uq_doctor_slot ON appointment (doctor_id, appointment_date, start_time)
    WHERE status <> 'CANCELLED';

CREATE TABLE prescription (
    prescription_id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    appointment_id  INT  NOT NULL REFERENCES appointment(appointment_id),
    prescribed_on   DATE NOT NULL DEFAULT CURRENT_DATE,
    diagnosis       TEXT NOT NULL,
    notes           TEXT
);
-- Makes full-text search on the diagnosis fast.
CREATE INDEX idx_prescription_fts ON prescription USING GIN (to_tsvector('english', diagnosis));

CREATE TABLE supplier (
    supplier_id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    name        VARCHAR(80) NOT NULL UNIQUE,
    phone_no    VARCHAR(15),
    city        VARCHAR(50)
);

CREATE TABLE medicine (
    medicine_id   INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    supplier_id   INT          NOT NULL REFERENCES supplier(supplier_id),
    name          VARCHAR(80)  NOT NULL UNIQUE,
    unit_price    NUMERIC(8,2) NOT NULL CHECK (unit_price >= 0),
    reorder_level INT          NOT NULL DEFAULT 50 CHECK (reorder_level >= 0)
);

-- Weak entity: a batch number is only unique within its medicine.
CREATE TABLE stock_batch (
    medicine_id INT         NOT NULL REFERENCES medicine(medicine_id) ON DELETE CASCADE,
    batch_no    VARCHAR(20) NOT NULL,
    quantity    INT         NOT NULL CHECK (quantity >= 0),
    expiry_date DATE        NOT NULL,
    PRIMARY KEY (medicine_id, batch_no)
);

-- M:N relationship "Contains", with its own attributes.
CREATE TABLE prescription_medicine (
    prescription_id INT         NOT NULL REFERENCES prescription(prescription_id) ON DELETE CASCADE,
    medicine_id     INT         NOT NULL REFERENCES medicine(medicine_id),
    dosage          VARCHAR(30) NOT NULL,
    frequency       VARCHAR(30) NOT NULL,
    duration_days   SMALLINT    NOT NULL CHECK (duration_days > 0),
    quantity        INT         NOT NULL CHECK (quantity > 0),
    dispensed       BOOLEAN     NOT NULL DEFAULT FALSE,
    PRIMARY KEY (prescription_id, medicine_id)
);

CREATE TABLE bed (
    bed_id     INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    ward       VARCHAR(30)  NOT NULL,
    bed_no     VARCHAR(10)  NOT NULL,
    daily_rate NUMERIC(8,2) NOT NULL CHECK (daily_rate >= 0),
    status     VARCHAR(12)  NOT NULL DEFAULT 'AVAILABLE'
               CHECK (status IN ('AVAILABLE','OCCUPIED','MAINTENANCE')),
    UNIQUE (ward, bed_no)
);

CREATE TABLE admission (
    admission_id  INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    patient_id    INT  NOT NULL REFERENCES patient(patient_id),
    doctor_id     INT  NOT NULL REFERENCES doctor(doctor_id),
    bed_id        INT  NOT NULL REFERENCES bed(bed_id),
    admitted_on   DATE NOT NULL DEFAULT CURRENT_DATE,
    discharged_on DATE,
    reason        VARCHAR(200),
    CHECK (discharged_on IS NULL OR discharged_on >= admitted_on)
);
-- A bed, or a patient, can only be in one open admission at a time.
CREATE UNIQUE INDEX uq_open_bed     ON admission (bed_id)     WHERE discharged_on IS NULL;
CREATE UNIQUE INDEX uq_open_patient ON admission (patient_id) WHERE discharged_on IS NULL;

CREATE TABLE bill (
    bill_id        INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    patient_id     INT         NOT NULL REFERENCES patient(patient_id),
    appointment_id INT UNIQUE  REFERENCES appointment(appointment_id),
    admission_id   INT UNIQUE  REFERENCES admission(admission_id),
    policy_id      INT         REFERENCES policy(policy_id) ON DELETE SET NULL,
    bill_date      DATE        NOT NULL DEFAULT CURRENT_DATE,
    status         VARCHAR(10) NOT NULL DEFAULT 'UNPAID' CHECK (status IN ('UNPAID','PARTIAL','PAID')),
    -- A bill comes from exactly one appointment or one admission.
    CHECK (num_nonnulls(appointment_id, admission_id) = 1)
);

-- Weak entity: a line number is only unique within its bill.
CREATE TABLE bill_item (
    bill_id     INT           NOT NULL REFERENCES bill(bill_id) ON DELETE CASCADE,
    item_no     SMALLINT      NOT NULL,
    description VARCHAR(120)  NOT NULL,
    quantity    INT           NOT NULL DEFAULT 1 CHECK (quantity > 0),
    unit_price  NUMERIC(10,2) NOT NULL CHECK (unit_price >= 0),
    PRIMARY KEY (bill_id, item_no)
);

CREATE TABLE payment (
    payment_id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    bill_id    INT           NOT NULL REFERENCES bill(bill_id),
    amount     NUMERIC(10,2) NOT NULL CHECK (amount > 0),
    method     VARCHAR(10)   NOT NULL CHECK (method IN ('CASH','CARD','UPI')),
    paid_on    DATE          NOT NULL DEFAULT CURRENT_DATE
);
