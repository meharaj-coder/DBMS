-- Sample data. All people and organisations are made up.
-- Dates are relative to the day the database is created, so the demo always looks current.

INSERT INTO department (name, location) VALUES
('Cardiology','Block A, Floor 2'), ('Orthopaedics','Block A, Floor 3'), ('Paediatrics','Block B, Floor 1'),
('General Medicine','Block B, Floor 2'), ('Neurology','Block C, Floor 2');

INSERT INTO doctor (department_id, first_name, last_name, specialization, email, joining_date, consultation_fee) VALUES
(1,'Asha','Rao','Interventional Cardiology','asha.rao@hms.example','2012-06-11',900),
(1,'Vikram','Menon','Clinical Cardiology','vikram.menon@hms.example','2018-01-15',750),
(2,'Neha','Kulkarni','Joint Replacement','neha.kulkarni@hms.example','2015-03-02',800),
(3,'Priya','Nair','General Paediatrics','priya.nair@hms.example','2016-11-07',600),
(4,'Karthik','Reddy','Internal Medicine','karthik.reddy@hms.example','2010-07-01',500),
(5,'Arjun','Hegde','Clinical Neurology','arjun.hegde@hms.example','2014-09-09',1000);

INSERT INTO doctor_phone VALUES
(1,'9845000101'),(1,'9845000111'),(2,'9845000102'),(3,'9845000103'),(4,'9845000104'),(5,'9845000105'),(6,'9845000106');

INSERT INTO user_account (username, password_hash, role, doctor_id) VALUES
('admin',     crypt('admin123',     gen_salt('bf')), 'ADMIN',        NULL),
('reception', crypt('reception123', gen_salt('bf')), 'RECEPTIONIST', NULL),
('pharmacy',  crypt('pharmacy123',  gen_salt('bf')), 'PHARMACIST',   NULL),
('dr.rao',    crypt('doctor123',    gen_salt('bf')), 'DOCTOR', 1),
('dr.menon',  crypt('doctor123',    gen_salt('bf')), 'DOCTOR', 2),
('dr.kulkarni',crypt('doctor123',   gen_salt('bf')), 'DOCTOR', 3),
('dr.nair',   crypt('doctor123',    gen_salt('bf')), 'DOCTOR', 4),
('dr.reddy',  crypt('doctor123',    gen_salt('bf')), 'DOCTOR', 5),
('dr.hegde',  crypt('doctor123',    gen_salt('bf')), 'DOCTOR', 6);

-- Every doctor works 9 to 12, Monday to Saturday. Dr. Reddy also has a Sunday clinic.
INSERT INTO schedule (doctor_id, day_of_week, start_time, end_time, slot_minutes)
SELECT d.doctor_id, day, '09:00', '12:00', 20
FROM   doctor d CROSS JOIN generate_series(1, 6) AS day;
INSERT INTO schedule (doctor_id, day_of_week, start_time, end_time, slot_minutes) VALUES (5, 0, '10:00', '13:00', 20);

INSERT INTO patient (first_name, last_name, date_of_birth, gender, blood_group, street, city, state, zip, registered_on) VALUES
('Aarav','Sharma','1985-04-12','M','O+','12 MG Road','Bengaluru','Karnataka','560001',CURRENT_DATE-200),
('Diya','Krishnan','1992-09-30','F','A+','45 Jayanagar 4th Block','Bengaluru','Karnataka','560011',CURRENT_DATE-190),
('Ishaan','Gowda','2016-01-22','M','B+','8 Banashankari 2nd Stage','Bengaluru','Karnataka','560070',CURRENT_DATE-150),
('Ananya','Bhat','1978-11-03','F','AB+','22 Malleshwaram 8th Cross','Bengaluru','Karnataka','560003',CURRENT_DATE-120),
('Vivaan','Shetty','1969-06-18','M','O-','5 Indiranagar 100ft Road','Bengaluru','Karnataka','560038',CURRENT_DATE-100),
('Kavya','Pillai','2001-02-14','F','B-','77 HSR Layout Sector 3','Bengaluru','Karnataka','560102',CURRENT_DATE-90),
('Reyansh','Das','1955-12-25','M','A-','31 Koramangala 5th Block','Bengaluru','Karnataka','560095',CURRENT_DATE-60),
('Saanvi','Murthy','1988-07-07','F','O+','19 Basavanagudi','Bengaluru','Karnataka','560004',CURRENT_DATE-30),
('Advait','Naik','2010-10-10','M','A+','3 Vijayanagar','Mysuru','Karnataka','570017',CURRENT_DATE-20),
('Myra','Kamath','1995-03-21','F','B+','60 Whitefield Main Road','Bengaluru','Karnataka','560066',CURRENT_DATE-15);

INSERT INTO patient_phone VALUES
(1,'9886010001'),(1,'9900020001'),(2,'9886010002'),(3,'9886010003'),(4,'9886010004'),(4,'9900020004'),
(5,'9886010005'),(6,'9886010006'),(7,'9886010007'),(8,'9886010008'),(9,'9886010009'),(10,'9886010010');

INSERT INTO policy (patient_id, provider, policy_no, coverage_percent, max_coverage, valid_to) VALUES
(1,'Suraksha Health','SH-100231',80,200000,CURRENT_DATE+300),
(4,'Nirmaya General','NG-554120',70,150000,CURRENT_DATE+200);

INSERT INTO supplier (name, phone_no, city) VALUES
('Deccan Pharma Distributors','08041120001','Bengaluru'),
('Kaveri Medical Supplies','08041120002','Mysuru'),
('Nandi Lifesciences','08041120003','Bengaluru');

-- The ids here match the Medicine nodes in database/neo4j/01_create_graph.cypher.
INSERT INTO medicine (supplier_id, name, unit_price, reorder_level) VALUES
(1,'Paracetamol 500 mg',2.00,100),(1,'Ibuprofen 400 mg',3.50,80),(2,'Aspirin 75 mg',1.50,80),
(3,'Warfarin 5 mg',4.00,40),(3,'Atorvastatin 20 mg',8.50,60),(3,'Amlodipine 5 mg',3.00,60),
(2,'Ramipril 5 mg',7.00,50),(1,'Metformin 500 mg',2.50,100),(1,'Omeprazole 20 mg',4.00,80),
(2,'Amoxicillin 500 mg',6.00,60),(2,'Azithromycin 500 mg',18.00,40),(3,'Cetirizine 10 mg',2.00,50);

INSERT INTO stock_batch (medicine_id, batch_no, quantity, expiry_date) VALUES
(1,'PCM-01',150,CURRENT_DATE+60),(1,'PCM-02',200,CURRENT_DATE+400),(2,'IBU-01',120,CURRENT_DATE+200),
(3,'ASP-01',160,CURRENT_DATE+300),(4,'WAR-01',25,CURRENT_DATE+150),(5,'ATO-01',90,CURRENT_DATE+250),
(6,'AML-01',100,CURRENT_DATE+45),(7,'RAM-01',30,CURRENT_DATE+180),(8,'MET-01',180,CURRENT_DATE+365),
(9,'OME-01',110,CURRENT_DATE+90),(10,'AMX-01',70,CURRENT_DATE+120),(11,'AZI-01',15,CURRENT_DATE-5),
(11,'AZI-02',50,CURRENT_DATE+300),(12,'CET-01',80,CURRENT_DATE+500);

INSERT INTO bed (ward, bed_no, daily_rate) VALUES
('General Ward','G-01',1200),('General Ward','G-02',1200),('General Ward','G-03',1200),('General Ward','G-04',1200),
('Private Wing','P-01',3500),('Private Wing','P-02',3500),('ICU','I-01',9000),('ICU','I-02',9000);
UPDATE bed SET status = 'MAINTENANCE' WHERE bed_no = 'G-04';

INSERT INTO appointment (patient_id, doctor_id, appointment_date, start_time, status, reason) VALUES
(1,1,CURRENT_DATE-100,'09:00','COMPLETED','Chest pain on exertion'),
(2,5,CURRENT_DATE-95, '09:20','COMPLETED','Fever and body ache'),
(3,4,CURRENT_DATE-70, '10:00','COMPLETED','Ear pain'),
(4,3,CURRENT_DATE-65, '09:40','COMPLETED','Lower back pain'),
(5,1,CURRENT_DATE-40, '11:00','COMPLETED','High blood pressure'),
(6,6,CURRENT_DATE-35, '09:00','COMPLETED','Recurring headache'),
(1,2,CURRENT_DATE-20, '10:20','COMPLETED','Palpitations'),
(7,5,CURRENT_DATE-10, '09:00','COMPLETED','Increased thirst and fatigue'),
(8,3,CURRENT_DATE-3,  '10:40','COMPLETED','Knee pain'),
(9,4,CURRENT_DATE-2,  '09:20','COMPLETED','Skin allergy with fever'),
(10,5,CURRENT_DATE-15,'11:20','CANCELLED','Acidity'),
(2,6,CURRENT_DATE-12, '10:00','NO_SHOW','Numbness in feet'),
(3,4,CURRENT_DATE+1,  '09:00','SCHEDULED','Follow-up for ear pain'),
(5,2,CURRENT_DATE+1,  '09:40','SCHEDULED','Blood pressure review'),
(6,5,CURRENT_DATE+2,  '10:20','SCHEDULED','General check-up'),
(9,3,CURRENT_DATE+3,  '11:00','SCHEDULED','Sports injury');

INSERT INTO prescription (appointment_id, prescribed_on, diagnosis, notes) VALUES
(1, CURRENT_DATE-100,'Stable angina with exertional chest pain','Review with ECG in two weeks'),
(2, CURRENT_DATE-95, 'Acute viral fever','Plenty of fluids and rest'),
(3, CURRENT_DATE-70, 'Acute otitis media','Complete the antibiotic course'),
(4, CURRENT_DATE-65, 'Lumbar strain with muscle spasm','Avoid lifting; hot compress twice daily'),
(5, CURRENT_DATE-40, 'Essential hypertension','Keep a home blood pressure log'),
(6, CURRENT_DATE-35, 'Migraine without aura','Maintain a headache diary'),
(7, CURRENT_DATE-20, 'Atrial fibrillation with palpitations','Monitor INR weekly'),
(8, CURRENT_DATE-10, 'Type 2 diabetes, newly diagnosed','Diet counselling; HbA1c after three months'),
(9, CURRENT_DATE-3,  'Osteoarthritis of the right knee','Physiotherapy advised'),
(10,CURRENT_DATE-2,  'Allergic rash with viral fever','Return if the fever continues');

-- Prescriptions 9 and 10 are left for the pharmacist to dispense in the demo.
INSERT INTO prescription_medicine (prescription_id, medicine_id, dosage, frequency, duration_days, quantity, dispensed) VALUES
(1,3,'1 tablet','Once daily',10,10,TRUE),(1,5,'1 tablet','Once daily',10,10,TRUE),
(2,1,'1 tablet','Twice daily',5,10,TRUE),
(3,10,'1 capsule','Twice daily',5,10,TRUE),(3,1,'1 tablet','Twice daily',5,10,TRUE),
(4,2,'1 tablet','Twice daily',5,10,TRUE),(4,9,'1 capsule','Twice daily',5,10,TRUE),
(5,6,'1 tablet','Once daily',10,10,TRUE),(5,7,'1 tablet','Once daily',10,10,TRUE),
(6,1,'1 tablet','Twice daily',5,10,TRUE),
(7,4,'1 tablet','Once daily',10,10,TRUE),
(8,8,'1 tablet','Twice daily',5,10,TRUE),
(9,2,'1 tablet','Twice daily',5,10,FALSE),(9,9,'1 capsule','Twice daily',5,10,FALSE),
(10,1,'1 tablet','Twice daily',5,10,FALSE),(10,12,'1 tablet','Once daily',10,10,FALSE);

-- Past stay, followed by two current in-patients. The trigger updates bed.status.
INSERT INTO admission (patient_id, doctor_id, bed_id, admitted_on, discharged_on, reason) VALUES
(2,5,1,CURRENT_DATE-60,CURRENT_DATE-56,'Severe dehydration'),
(5,1,7,CURRENT_DATE-2,NULL,'Acute myocardial infarction, under monitoring'),
(7,5,2,CURRENT_DATE-4,NULL,'Community acquired pneumonia');

INSERT INTO bill (patient_id, appointment_id, admission_id, policy_id, bill_date) VALUES
(1,1,NULL,1,CURRENT_DATE-100),(2,2,NULL,NULL,CURRENT_DATE-95),(3,3,NULL,NULL,CURRENT_DATE-70),
(4,4,NULL,2,CURRENT_DATE-65),(5,5,NULL,NULL,CURRENT_DATE-40),(6,6,NULL,NULL,CURRENT_DATE-35),
(1,7,NULL,1,CURRENT_DATE-20),(7,8,NULL,NULL,CURRENT_DATE-10),(8,9,NULL,NULL,CURRENT_DATE-3),
(9,10,NULL,NULL,CURRENT_DATE-2),(2,NULL,1,NULL,CURRENT_DATE-56);

INSERT INTO bill_item (bill_id, item_no, description, quantity, unit_price) VALUES
(1,1,'Doctor consultation',1,900),(1,2,'Aspirin 75 mg',10,1.50),(1,3,'Atorvastatin 20 mg',10,8.50),
(2,1,'Doctor consultation',1,500),(2,2,'Paracetamol 500 mg',10,2.00),
(3,1,'Doctor consultation',1,600),(3,2,'Paracetamol 500 mg',10,2.00),(3,3,'Amoxicillin 500 mg',10,6.00),
(4,1,'Doctor consultation',1,800),(4,2,'Ibuprofen 400 mg',10,3.50),(4,3,'Omeprazole 20 mg',10,4.00),
(5,1,'Doctor consultation',1,900),(5,2,'Amlodipine 5 mg',10,3.00),(5,3,'Ramipril 5 mg',10,7.00),
(6,1,'Doctor consultation',1,1000),(6,2,'Paracetamol 500 mg',10,2.00),
(7,1,'Doctor consultation',1,750),(7,2,'Warfarin 5 mg',10,4.00),
(8,1,'Doctor consultation',1,500),(8,2,'Metformin 500 mg',10,2.50),
(9,1,'Doctor consultation',1,800),
(10,1,'Doctor consultation',1,600),
(11,1,'Bed charges',4,1200);

-- The triggers check each amount and set bill.status. Bill 6 stays part-paid; 9 and 10 stay unpaid.
INSERT INTO payment (bill_id, amount, method, paid_on) VALUES
(1,200,'UPI',CURRENT_DATE-100),(2,520,'CASH',CURRENT_DATE-95),(3,680,'CARD',CURRENT_DATE-70),
(4,262.50,'UPI',CURRENT_DATE-65),(11,4800,'CARD',CURRENT_DATE-56),(5,1000,'CASH',CURRENT_DATE-40),
(6,500,'UPI',CURRENT_DATE-35),(7,158,'CARD',CURRENT_DATE-20),(8,525,'CASH',CURRENT_DATE-10);
