-- Triggers and stored procedures.

-- Trigger 1: a payment cannot be more than what is still due.
CREATE FUNCTION trg_fn_check_payment() RETURNS TRIGGER
LANGUAGE plpgsql AS $$
BEGIN
    -- Lock the bill so two payments at the same moment cannot both pass the check.
    PERFORM 1 FROM bill WHERE bill_id = NEW.bill_id FOR UPDATE;
    IF NEW.amount > fn_bill_due(NEW.bill_id) THEN
        RAISE EXCEPTION 'Payment of % is more than the amount due (%)', NEW.amount, fn_bill_due(NEW.bill_id);
    END IF;
    RETURN NEW;
END $$;

CREATE TRIGGER trg_check_payment
BEFORE INSERT ON payment
FOR EACH ROW EXECUTE FUNCTION trg_fn_check_payment();

-- Trigger 2: keep bill.status correct whenever a payment or bill item is added.
CREATE FUNCTION trg_fn_update_bill_status() RETURNS TRIGGER
LANGUAGE plpgsql AS $$
BEGIN
    UPDATE bill
    SET    status = CASE
               WHEN fn_bill_total(bill_id) > 0 AND fn_bill_due(bill_id) <= 0 THEN 'PAID'
               WHEN EXISTS (SELECT 1 FROM payment p WHERE p.bill_id = bill.bill_id) THEN 'PARTIAL'
               ELSE 'UNPAID'
           END
    WHERE  bill_id = NEW.bill_id;
    RETURN NEW;
END $$;

CREATE TRIGGER trg_payment_status
AFTER INSERT ON payment
FOR EACH ROW EXECUTE FUNCTION trg_fn_update_bill_status();

CREATE TRIGGER trg_bill_item_status
AFTER INSERT ON bill_item
FOR EACH ROW EXECUTE FUNCTION trg_fn_update_bill_status();

-- Trigger 3: keep bed.status correct when a patient is admitted or discharged.
CREATE FUNCTION trg_fn_update_bed_status() RETURNS TRIGGER
LANGUAGE plpgsql AS $$
BEGIN
    UPDATE bed
    SET    status = CASE WHEN NEW.discharged_on IS NULL THEN 'OCCUPIED' ELSE 'AVAILABLE' END
    WHERE  bed_id = NEW.bed_id;
    RETURN NEW;
END $$;

CREATE TRIGGER trg_bed_status
AFTER INSERT OR UPDATE OF discharged_on ON admission
FOR EACH ROW EXECUTE FUNCTION trg_fn_update_bed_status();

-- The procedures below are SECURITY DEFINER: they run with the owner's rights, so a
-- role can do this one job without direct access to every table it touches. For
-- example, a doctor can complete an appointment, which creates a bill, without being
-- able to read or edit bills.

CREATE PROCEDURE sp_book_appointment(p_patient_id INT, p_doctor_id INT, p_date DATE, p_time TIME, p_reason VARCHAR)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
    IF p_date < CURRENT_DATE THEN
        RAISE EXCEPTION 'Appointment date cannot be in the past';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM fn_available_slots(p_doctor_id, p_date) WHERE slot_time = p_time) THEN
        RAISE EXCEPTION 'That slot is not available';
    END IF;
    INSERT INTO appointment (patient_id, doctor_id, appointment_date, start_time, reason)
    VALUES (p_patient_id, p_doctor_id, p_date, p_time, p_reason);
END $$;

-- Marks the appointment completed and creates its bill with the consultation fee.
CREATE PROCEDURE sp_complete_appointment(p_appointment_id INT)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
    v_patient INT;
    v_fee     NUMERIC;
    v_policy  INT;
    v_bill    INT;
BEGIN
    SELECT a.patient_id, d.consultation_fee INTO v_patient, v_fee
    FROM   appointment a JOIN doctor d ON d.doctor_id = a.doctor_id
    WHERE  a.appointment_id = p_appointment_id AND a.status = 'SCHEDULED'
    FOR UPDATE OF a;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Appointment % is not in SCHEDULED status', p_appointment_id;
    END IF;

    UPDATE appointment SET status = 'COMPLETED' WHERE appointment_id = p_appointment_id;

    SELECT policy_id INTO v_policy FROM policy
    WHERE  patient_id = v_patient AND valid_to >= CURRENT_DATE LIMIT 1;

    INSERT INTO bill (patient_id, appointment_id, policy_id)
    VALUES (v_patient, p_appointment_id, v_policy)
    RETURNING bill_id INTO v_bill;

    INSERT INTO bill_item (bill_id, item_no, description, quantity, unit_price)
    VALUES (v_bill, 1, 'Doctor consultation', 1, v_fee);
END $$;

-- Closes the admission (the trigger frees the bed) and bills the stay.
CREATE PROCEDURE sp_discharge_patient(p_admission_id INT)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
    v_adm    admission%ROWTYPE;
    v_rate   NUMERIC;
    v_policy INT;
    v_bill   INT;
BEGIN
    SELECT * INTO v_adm FROM admission
    WHERE  admission_id = p_admission_id AND discharged_on IS NULL
    FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Admission % is not open', p_admission_id;
    END IF;

    UPDATE admission SET discharged_on = CURRENT_DATE WHERE admission_id = p_admission_id;

    SELECT daily_rate INTO v_rate FROM bed WHERE bed_id = v_adm.bed_id;
    SELECT policy_id INTO v_policy FROM policy
    WHERE  patient_id = v_adm.patient_id AND valid_to >= CURRENT_DATE LIMIT 1;

    INSERT INTO bill (patient_id, admission_id, policy_id)
    VALUES (v_adm.patient_id, p_admission_id, v_policy)
    RETURNING bill_id INTO v_bill;

    INSERT INTO bill_item (bill_id, item_no, description, quantity, unit_price)
    VALUES (v_bill, 1, 'Bed charges', GREATEST(1, CURRENT_DATE - v_adm.admitted_on), v_rate);
END $$;

-- Takes each medicine from the batches that expire first and adds it to the bill.
-- If any medicine is short, the RAISE rolls the whole transaction back, so a
-- prescription is never half dispensed.
CREATE PROCEDURE sp_dispense_prescription(p_prescription_id INT)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
    v_bill   INT;
    v_line   RECORD;
    v_batch  RECORD;
    v_needed INT;
    v_taken  INT;
BEGIN
    SELECT b.bill_id INTO v_bill
    FROM   prescription r JOIN bill b ON b.appointment_id = r.appointment_id
    WHERE  r.prescription_id = p_prescription_id;
    IF v_bill IS NULL THEN
        RAISE EXCEPTION 'Complete the appointment before dispensing this prescription';
    END IF;

    FOR v_line IN
        SELECT pm.medicine_id, pm.quantity, m.name, m.unit_price
        FROM   prescription_medicine pm JOIN medicine m ON m.medicine_id = pm.medicine_id
        WHERE  pm.prescription_id = p_prescription_id AND NOT pm.dispensed
    LOOP
        v_needed := v_line.quantity;

        FOR v_batch IN
            SELECT batch_no, quantity FROM stock_batch
            WHERE  medicine_id = v_line.medicine_id AND quantity > 0 AND expiry_date > CURRENT_DATE
            ORDER  BY expiry_date
            FOR UPDATE       -- no one else can take from these batches until we commit
        LOOP
            EXIT WHEN v_needed = 0;
            v_taken := LEAST(v_needed, v_batch.quantity);
            UPDATE stock_batch SET quantity = quantity - v_taken
            WHERE  medicine_id = v_line.medicine_id AND batch_no = v_batch.batch_no;
            v_needed := v_needed - v_taken;
        END LOOP;

        IF v_needed > 0 THEN
            RAISE EXCEPTION 'Not enough stock of %: short by %', v_line.name, v_needed;
        END IF;

        UPDATE prescription_medicine SET dispensed = TRUE
        WHERE  prescription_id = p_prescription_id AND medicine_id = v_line.medicine_id;

        INSERT INTO bill_item (bill_id, item_no, description, quantity, unit_price)
        SELECT v_bill, MAX(item_no) + 1, v_line.name, v_line.quantity, v_line.unit_price
        FROM   bill_item WHERE bill_id = v_bill;
    END LOOP;
END $$;
