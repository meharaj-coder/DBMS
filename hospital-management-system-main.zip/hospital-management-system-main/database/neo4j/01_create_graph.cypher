// Medicine interaction graph. medicine_id matches the primary key in PostgreSQL.
// The interaction data is sample content for this project, not medical advice.
// MERGE means the file can safely be run more than once.

CREATE CONSTRAINT medicine_id_unique IF NOT EXISTS
FOR (m:Medicine) REQUIRE m.medicine_id IS UNIQUE;

UNWIND [
  {id:1,name:'Paracetamol 500 mg'},{id:2,name:'Ibuprofen 400 mg'},{id:3,name:'Aspirin 75 mg'},
  {id:4,name:'Warfarin 5 mg'},{id:5,name:'Atorvastatin 20 mg'},{id:6,name:'Amlodipine 5 mg'},
  {id:7,name:'Ramipril 5 mg'},{id:8,name:'Metformin 500 mg'},{id:9,name:'Omeprazole 20 mg'},
  {id:10,name:'Amoxicillin 500 mg'},{id:11,name:'Azithromycin 500 mg'},{id:12,name:'Cetirizine 10 mg'}
] AS row
MERGE (m:Medicine {medicine_id: row.id})
SET m.name = row.name;

UNWIND [
  {a:3,b:4,severity:'MAJOR',effect:'Greatly increased risk of bleeding'},
  {a:2,b:4,severity:'MAJOR',effect:'Increased risk of bleeding'},
  {a:2,b:3,severity:'MODERATE',effect:'Reduces the heart-protective effect of aspirin'},
  {a:2,b:7,severity:'MODERATE',effect:'Reduces blood pressure control'},
  {a:4,b:11,severity:'MODERATE',effect:'May raise warfarin levels'},
  {a:5,b:6,severity:'MINOR',effect:'Slightly raised statin levels'},
  {a:1,b:4,severity:'MINOR',effect:'Regular high doses may raise INR'},
  {a:4,b:9,severity:'MINOR',effect:'May slightly raise warfarin levels'}
] AS row
MATCH (a:Medicine {medicine_id: row.a}), (b:Medicine {medicine_id: row.b})
MERGE (a)-[r:INTERACTS_WITH]->(b)
SET r.severity = row.severity, r.effect = row.effect;
