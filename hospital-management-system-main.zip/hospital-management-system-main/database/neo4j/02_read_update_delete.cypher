// Read, update and delete on the interaction graph. The web app runs the same
// kind of queries from its /api/interactions routes.

// READ: every interaction, grouped by severity
MATCH (a:Medicine)-[r:INTERACTS_WITH]->(b:Medicine)
RETURN a.name AS medicine, b.name AS interacts_with, r.severity AS severity, r.effect AS effect
ORDER BY r.severity, a.name;

// READ: everything that interacts with Warfarin, whichever direction it was stored in
MATCH (:Medicine {name: 'Warfarin 5 mg'})-[r:INTERACTS_WITH]-(other:Medicine)
RETURN other.name AS interacts_with, r.severity AS severity;

// READ: check the medicines on one prescription
MATCH (a:Medicine)-[r:INTERACTS_WITH]->(b:Medicine)
WHERE a.medicine_id IN [2, 3, 4] AND b.medicine_id IN [2, 3, 4]
RETURN a.name AS medicine, b.name AS interacts_with, r.severity AS severity;

// READ: medicines two steps away from Aspirin (a graph traversal)
MATCH path = (:Medicine {name: 'Aspirin 75 mg'})-[:INTERACTS_WITH*2]-(other:Medicine)
WHERE other.name <> 'Aspirin 75 mg'
RETURN DISTINCT other.name AS two_steps_away;

// CREATE: add a test interaction
MATCH (a:Medicine {medicine_id: 10}), (b:Medicine {medicine_id: 12})
MERGE (a)-[r:INTERACTS_WITH]->(b)
SET r.severity = 'MINOR', r.effect = 'Test interaction'
RETURN a.name AS medicine, b.name AS interacts_with, r.severity AS severity;

// UPDATE: change its severity
MATCH (:Medicine {medicine_id: 10})-[r:INTERACTS_WITH]->(:Medicine {medicine_id: 12})
SET r.severity = 'MODERATE'
RETURN r.severity AS new_severity;

// DELETE: remove it
MATCH (:Medicine {medicine_id: 10})-[r:INTERACTS_WITH]->(:Medicine {medicine_id: 12})
DELETE r
RETURN count(r) AS deleted;

// COUNT: the graph is back to its original size
MATCH (m:Medicine) WITH count(m) AS medicines
MATCH ()-[r:INTERACTS_WITH]->()
RETURN medicines, count(r) AS interactions;
